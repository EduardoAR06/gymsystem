package com.gym.gymsystem.service;

import com.gym.gymsystem.model.Membresia;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class MembresiaServiceTest {

    private MembresiaService service;

    @BeforeEach
    void setUp() {
        service = new MembresiaService();
    }

    // CREATE - Fase 1
    @Test
    @DisplayName("CREAR: guardar membresía le asigna un ID auto-generado")
    void cuandoSeGuardaMembresia_entoncesSeAsignaId() {
        // RED: Sin implementacion save(), la prueba falla porque no hay contador
        // GREEN: Agregamos AtomicLong en MembresiaService que incrementa
        // REFACTOR: AtomicLong es thread-safe e idiomatico para IDs auto-generados

        Membresia nueva = new Membresia(null, "Plan Mensual", 80.0, "30 días");
        service.save(nueva);

        assertNotNull(nueva.getId(),
                "El ID no debe ser null después de guardar");
        assertTrue(nueva.getId() > 0,
                "El ID debe ser un número positivo");
    }

    // CREATE - Fase 2
    @Test
    @DisplayName("CREAR: la lista crece al agregar una nueva membresía")
    void cuandoSeGuardaMembresia_entoncesListaAumenta() {
        // RED: findAll() no existe o retorna lista vacía
        // GREEN: Implementamos findAll() que devuelve la lista interna
        // REFACTOR: List.copyOf() proporciona encapsulación defensiva

        Membresia m = new Membresia(null, "Plan Anual", 600.0, "365 días");
        service.save(m);

        assertEquals(1, service.findAll().size(),
                "Debe existir exactamente 1 membresía después de guardar");
    }

    // READ - Fase 1
    @Test
    @DisplayName("LEER: buscar membresía por ID existente retorna el objeto")
    void cuandoBuscoMembresiaPorIdExistente_entoncesLaEncuentro() {
        // RED: findById() no existe
        // GREEN: Stream filter por ID, retorna Optional
        // REFACTOR: Optional es idioma de Java moderno para valores opcionales

        Membresia m = new Membresia(null, "Plan Trimestral", 200.0, "90 días");
        service.save(m);

        Optional<Membresia> resultado = service.findById(m.getId());

        assertTrue(resultado.isPresent(),
                "Debe encontrarse la membresía guardada");
        assertEquals("Plan Trimestral", resultado.get().getPlan());
    }

    // READ - Fase 2
    @Test
    @DisplayName("LEER: buscar membresía por ID inexistente retorna vacío")
    void cuandoBuscoMembresiaPorIdInexistente_entoncesNoLaEncuentro() {
        // RED: Retorna null o excepcion
        // GREEN: Stream no encuentra match, Optional.empty()
        // REFACTOR: Optional.empty() es preferible a null para errores suave

        Optional<Membresia> resultado = service.findById(999L);

        assertFalse(resultado.isPresent(),
                "No debe encontrarse ninguna membresía con ID 999");
    }

    // UPDATE
    @Test
    @DisplayName("ACTUALIZAR: modificar plan de membresía existente")
    void cuandoActualizoMembresia_entoncesLosDatosCambian() {
        // RED: Sin implementacion update(), cambios no persisten
        // GREEN: Iteramos lista, encontramos por ID, reemplazamos
        // REFACTOR: Iteracion clara sin cambios de paradigma

        Membresia original = new Membresia(null, "Plan Básico", 50.0, "30 días");
        service.save(original);

        Membresia actualizada = new Membresia(original.getId(), "Plan Premium", 150.0, "30 días");
        service.update(actualizada);

        Optional<Membresia> encontrada = service.findById(original.getId());
        assertTrue(encontrada.isPresent());
        assertEquals("Plan Premium", encontrada.get().getPlan(),
                "El plan debe haber cambiado a 'Plan Premium'");
        assertEquals(150.0, encontrada.get().getPrecio(),
                "El precio debe haber actualizado a 150.0");
    }

    // DELETE
    @Test
    @DisplayName("ELIMINAR: al borrar una membresía ya no aparece en la lista")
    void cuandoEliminoMembresia_entoncesDesapareceDelaLista() {
        // RED: Sin implementacion deleteById(), elemento permanece
        // GREEN: removeIf() elimina el elemento que cumple predicado
        // REFACTOR: Lambda y removeIf() son idiomaticos para esta operacion

        Membresia m = new Membresia(null, "Plan Semestral", 350.0, "180 días");
        service.save(m);
        Long idGuardado = m.getId();

        service.deleteById(idGuardado);

        Optional<Membresia> resultado = service.findById(idGuardado);
        assertFalse(resultado.isPresent(),
                "La membresía eliminada no debe encontrarse");

        List<Membresia> lista = service.findAll();
        assertEquals(0, lista.size(),
                "La lista debe estar vacía tras eliminar el único elemento");
    }
}
