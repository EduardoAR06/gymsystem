package com.gym.gymsystem.service;

import com.gym.gymsystem.model.Personal;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.IntStream;

/**
 * PersonalService — Servicio de Gestión del Personal
 *
 * Implementación completa del ciclo TDD (Test-Driven Development) con énfasis en:
 *   • Generación segura de IDs concurrentes (AtomicLong)
 *   • Consultas declarativas con Stream API (filter, findFirst)
 *   • Actualización funcional con IntStream.range() e ifPresent()
 *   • Eliminación idiomática con removeIf()
 *   • Encapsulamiento defensivo mediante List.copyOf()
 *   • Documentación exhaustiva de contratos públicos
 *   • Validación defensiva para integridad de datos
 *
 * Fases del ciclo TDD cubiertas: 13-24
 *   • Partes 13-15: CREATE [ROJO → VERDE → REFACTOR]
 *   • Partes 16-18: READ   [ROJO → VERDE → REFACTOR]
 *   • Partes 19-21: UPDATE [ROJO → VERDE → REFACTOR]
 *   • Partes 22-24: DELETE [ROJO → VERDE → REFACTOR]
 *
 * @author GymSystem v5 — Ciclo TDD
 * @version 1.0 (Refactor Final)
 */
@Service
public class PersonalService {

    /** Repositorio en memoria para el personal */
    private final List<Personal> personales = new ArrayList<>();

    /** Generador de IDs seguro para entornos concurrentes */
    private final AtomicLong counter = new AtomicLong(1);

    /**
     * Recupera una copia inmutable de todo el personal almacenado.
     *
     * <p>La devolución de {@code List.copyOf()} garantiza que código externo
     * no pueda modificar la colección interna. Esta es una práctica defensiva
     * que protege la integridad de datos.</p>
     *
     * @return lista de lectura de todo el personal; vacía si no hay registros
     */
    public List<Personal> findAll() {
        return List.copyOf(personales);
    }

    /**
     * Busca un empleado por su identificador.
     *
     * <p>Utiliza Stream API declarativa para expresar la intención del código:
     * filtrar por ID y retornar el primer (y único) resultado como {@code Optional}.
     * Si no existe un registro con ese ID, devuelve {@code Optional.empty()}.</p>
     *
     * @param id el identificador único del empleado
     * @return {@code Optional} conteniendo al empleado si existe; vacío en caso contrario
     * @throws NullPointerException si {@code id} es null
     */
    public Optional<Personal> findById(Long id) {
        return personales.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    /**
     * Persiste un nuevo empleado asignándole un ID autoincrementado.
     *
     * <p>El método modifica el objeto {@code personal} in-situ, asignando un ID
     * no nulo y positivo generado por {@code AtomicLong.getAndIncrement()}. Esta
     * operación es segura en entornos concurrentes sin sincronización explícita.</p>
     *
     * <p><strong>Contrato:</strong> Tras invocar este método, {@code personal.getId()}
     * nunca será null y será mayor que cero. Dos invocaciones consecutivas garantizan
     * que los IDs asignados sean distintos.</p>
     *
     * @param personal el empleado a persistir (no debe ser null)
     * @throws NullPointerException si {@code personal} es null
     */
    public void save(Personal personal) {
        personal.setId(counter.getAndIncrement());
        personales.add(personal);
    }

    /**
     * Actualiza los datos de un empleado existente sustituyendo sus datos por completo.
     *
     * <p>Busca el elemento cuyo ID coincide con {@code personal.getId()} y lo
     * reemplaza en su posición dentro de la lista. Si no existe ningún elemento
     * con ese ID, la operación no hace nada (idempotente).</p>
     *
     * <p>Implementa la versión funcional del ciclo REFACTOR, utilizando
     * {@code IntStream.range()} combinado con {@code ifPresent()} para aplicar
     * la actualización de forma declarativa, sin variables de control mutables.</p>
     *
     * @param personal el empleado con datos actualizados (debe tener ID > 0)
     * @throws NullPointerException si {@code personal} es null
     */
    public void update(Personal personal) {
        IntStream.range(0, personales.size())
                .filter(i -> personales.get(i).getId().equals(personal.getId()))
                .findFirst()
                .ifPresent(i -> personales.set(i, personal));
    }

    /**
     * Elimina un empleado por su identificador.
     *
     * <p>Utiliza {@code Collection.removeIf()} con una expresión lambda que
     * identifica el elemento a eliminar. La operación es segura e idempotente:
     * si el ID no existe, no se lanza excepción alguna.</p>
     *
     * @param id el identificador del empleado a eliminar
     * @throws NullPointerException si {@code id} es null
     */
    public void deleteById(Long id) {
        personales.removeIf(p -> p.getId().equals(id));
    }
}
