package com.gym.gymsystem.service;

import com.gym.gymsystem.model.Membresia;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.IntStream;

/**
 * MembresiaService — Servicio de Gestión de Membresías
 *
 * Implementación completa del ciclo TDD (Test-Driven Development) con énfasis en:
 *   • Generación segura de IDs concurrentes (AtomicLong)
 *   • Consultas declarativas con Stream API (filter, findFirst)
 *   • Actualización funcional con IntStream.range()
 *   • Eliminación idiomática con removeIf()
 *   • Encapsulamiento defensivo mediante List.copyOf()
 *   • Documentación exhaustiva de contratos públicos
 *
 * Fases del ciclo TDD cubiertas: 1-12
 *   • Partes 1-3:   CREATE [ROJO → VERDE → REFACTOR]
 *   • Partes 4-6:   READ   [ROJO → VERDE → REFACTOR]
 *   • Partes 7-9:   UPDATE [ROJO → VERDE → REFACTOR]
 *   • Partes 10-12: DELETE [ROJO → VERDE → REFACTOR]
 *
 * @author GymSystem v5 — Ciclo TDD
 * @version 1.0 (Refactor Final)
 */
@Service
public class MembresiaService {

    /** Repositorio en memoria para las membresías */
    private final List<Membresia> membresias = new ArrayList<>();

    /** Generador de IDs seguro para entornos concurrentes */
    private final AtomicLong counter = new AtomicLong(1);

    /**
     * Recupera una copia inmutable de todas las membresías almacenadas.
     *
     * <p>La devolución de {@code List.copyOf()} garantiza que código externo
     * no pueda modificar la colección interna. Esta es una práctica defensiva
     * que protege la integridad de datos.</p>
     *
     * @return lista de lectura de todas las membresías; vacía si no hay registros
     */
    public List<Membresia> findAll() {
        return List.copyOf(membresias);
    }

    /**
     * Busca una membresía por su identificador.
     *
     * <p>Utiliza Stream API declarativa para expresar la intención del código:
     * filtrar por ID y retornar el primer (y único) resultado como {@code Optional}.
     * Si no existe un registro con ese ID, devuelve {@code Optional.empty()}.</p>
     *
     * @param id el identificador único de la membresía
     * @return {@code Optional} conteniendo la membresía si existe; vacío en caso contrario
     * @throws NullPointerException si {@code id} es null
     */
    public Optional<Membresia> findById(Long id) {
        return membresias.stream()
                .filter(m -> m.getId().equals(id))
                .findFirst();
    }

    /**
     * Persiste una nueva membresía asignándole un ID autoincrementado.
     *
     * <p>El metodo modifica el objeto {@code membresia} in-situ, asignando un ID
     * no nulo y positivo generado por {@code AtomicLong.getAndIncrement()}. Esta
     * operación es segura en entornos concurrentes sin sincronización explícita.</p>
     *
     * <p><strong>Contrato:</strong> Tras invocar este metodo, {@code membresia.getId()}
     * nunca será null y será mayor que cero.</p>
     *
     * @param membresia la membresía a persistir (no debe ser null)
     * @throws NullPointerException si {@code membresia} es null
     */


//===== VERSION ROJA/VERDE =====
public void save(Membresia membresia) {
    membresia.setId(counter.getAndIncrement());
    membresias.add(membresia);
}


/*
// ===== VERSION REFACTOR =====
    private Long generarId() {
        return counter.getAndIncrement();
    }

    public void save(Membresia membresia) {
        membresia.setId(generarId());
        membresias.add(membresia);
    }
*/

    /**
     * Actualiza una membresía existente sustituyendo sus datos por completo.
     *
     * <p>Busca el elemento cuyo ID coincide con {@code membresia.getId()} y lo
     * reemplaza en su posición dentro de la lista. Si no existe ningún elemento
     * con ese ID, la operación no hace nada (idempotente).</p>
     *
     * <p>Implementa la versión funcional del ciclo REFACTOR, utilizando
     * {@code IntStream.range()} para obtener índices de forma declarativa.</p>
     *
     * @param membresia la membresía con datos actualizados (debe tener ID > 0)
     * @throws NullPointerException si {@code membresia} es null
     */
    public void update(Membresia membresia) {
        IntStream.range(0, membresias.size())
                .filter(i -> membresias.get(i).getId().equals(membresia.getId()))
                .findFirst()
                .ifPresent(i -> membresias.set(i, membresia));
    }

    /**
     * Elimina una membresía por su identificador.
     *
     * <p>Utiliza {@code Collection.removeIf()} con una expresión lambda que
     * identifica el elemento a eliminar. La operación es segura e idempotente:
     * si el ID no existe, no se lanza excepción alguna.</p>
     *
     * @param id el identificador de la membresía a eliminar
     * @throws NullPointerException si {@code id} es null
     */
    public void deleteById(Long id) {
        membresias.removeIf(m -> m.getId().equals(id));
    }
}
