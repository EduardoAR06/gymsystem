package com.gym.gymsystem.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity(name = "cobro")
@Table(name = "cobros")
public class CobroEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long miembroId;
    private Long membresiaId;
    private String miembroNombre;
    private String planPagado;
    private Double monto;
    private String metodoPago;
    private String estado;
    private LocalDate fecha;

    public CobroEntity() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getMiembroId() { return miembroId; }
    public void setMiembroId(Long miembroId) { this.miembroId = miembroId; }

    public Long getMembresiaId() { return membresiaId; }
    public void setMembresiaId(Long membresiaId) { this.membresiaId = membresiaId; }

    public String getMiembroNombre() { return miembroNombre; }
    public void setMiembroNombre(String miembroNombre) { this.miembroNombre = miembroNombre; }

    public String getPlanPagado() { return planPagado; }
    public void setPlanPagado(String planPagado) { this.planPagado = planPagado; }

    public Double getMonto() { return monto; }
    public void setMonto(Double monto) { this.monto = monto; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
}