package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Permisos;
import com.gym.gymsystem.model.RolSistema;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.RolService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/roles")
public class RolController {

    private final RolService rolService;
    public RolController(RolService rolService) { this.rolService = rolService; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeGestionarRoles()) return "redirect:/main";
        model.addAttribute("roles", rolService.findAll());
        model.addAttribute("permisosCatalogo", Permisos.catalogo());
        model.addAttribute("usuario", u);
        return "roles/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null || !u.puedeGestionarRoles()) return "redirect:/roles";
        model.addAttribute("rol", new RolSistema());
        model.addAttribute("permisosCatalogo", Permisos.catalogo());
        model.addAttribute("creando", true);
        model.addAttribute("editando", false);
        model.addAttribute("usuario", u);
        return "roles/form";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null || !u.puedeGestionarRoles()) return "redirect:/roles";
        RolSistema rol = rolService.findById(id).orElseThrow(() -> new RuntimeException("Rol no encontrado"));
        model.addAttribute("rol", rol);
        model.addAttribute("permisosCatalogo", Permisos.catalogo());
        model.addAttribute("editando", true);
        model.addAttribute("creando", false);
        model.addAttribute("usuario", u);
        return "roles/form";
    }

    @PostMapping("/guardar")
    public String guardar(@RequestParam String nombre,
                          @RequestParam(required = false) String codigo,
                          @RequestParam(required = false) String[] permisosSeleccionados,
                          RedirectAttributes ra) {
        RolSistema rol = new RolSistema();
        rol.setNombre(nombre.trim());
        rol.setCodigo(codigo != null ? codigo.trim() : null);
        rol.setPermisos(permisosSeleccionados != null ? Arrays.asList(permisosSeleccionados) : List.of());
        if (rol.getPermisos().isEmpty()) {
            ra.addFlashAttribute("error", "Seleccione al menos una interfaz para el rol.");
            return "redirect:/roles/nuevo";
        }
        rolService.save(rol);
        ra.addFlashAttribute("mensaje", "Rol creado correctamente.");
        return "redirect:/roles";
    }

    @PostMapping("/actualizar")
    public String actualizar(@RequestParam Long id,
                             @RequestParam String nombre,
                             @RequestParam(required = false) String codigo,
                             @RequestParam(required = false) String[] permisosSeleccionados,
                             RedirectAttributes ra) {
        RolSistema rol = rolService.findById(id).orElseThrow();
        rol.setNombre(nombre.trim());
        if (!rol.isSistema() && codigo != null && !codigo.isBlank()) {
            rol.setCodigo(codigo.trim());
        }
        rol.setPermisos(permisosSeleccionados != null ? Arrays.asList(permisosSeleccionados) : List.of());
        if (rol.getPermisos().isEmpty()) {
            ra.addFlashAttribute("error", "Seleccione al menos una interfaz para el rol.");
            return "redirect:/roles/editar/" + id;
        }
        rolService.update(rol);
        ra.addFlashAttribute("mensaje", "Rol actualizado.");
        return "redirect:/roles";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        rolService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Rol eliminado.");
        return "redirect:/roles";
    }
}
