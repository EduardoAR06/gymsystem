package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Permisos;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.RolService;
import com.gym.gymsystem.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UsuarioService usuarioService;
    private final RolService rolService;

    public AuthController(UsuarioService usuarioService, RolService rolService) {
        this.usuarioService = usuarioService;
        this.rolService = rolService;
    }

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          HttpSession session,
                          Model model) {
        return usuarioService.login(username, password).map(u -> {
            u.setPermisos(rolService.permisosDeRol(u.getRol()));
            u.setRolNombreDisplay(rolService.nombreDeRol(u.getRol()));
            session.setAttribute("usuarioLogueado", u);
            if (u.puedeUsarKioskAsistencias()) return "redirect:/asistencias/kiosk";
            if (u.tienePermiso(Permisos.ASISTENCIAS_PROPIAS) && !u.puedeVerHistorialCompletoAsistencias()) {
                return "redirect:/asistencias";
            }
            return "redirect:/main";
        }).orElseGet(() -> {
            model.addAttribute("error", "Usuario o contraseña incorrectos.");
            return "login";
        });
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
