package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.AsistenciaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface AsistenciaRepository extends JpaRepository<AsistenciaEntity, Long> {
    List<AsistenciaEntity> findByTrabajadorContainingIgnoreCase(String nombre);
    List<AsistenciaEntity> findByFechaBetweenOrderByFechaAsc(LocalDate desde, LocalDate hasta);
    List<AsistenciaEntity> findByDniAndFecha(String dni, LocalDate fecha);

    @Query("SELECT a.fecha, COUNT(a) FROM asistencia a WHERE a.fecha >= :desde GROUP BY a.fecha ORDER BY a.fecha ASC")
    List<Object[]> countByFechaRecientes(@Param("desde") LocalDate desde);

    @Query("SELECT MONTH(a.fecha), COUNT(a) FROM asistencia a WHERE YEAR(a.fecha) = :anio GROUP BY MONTH(a.fecha) ORDER BY MONTH(a.fecha)")
    List<Object[]> asistenciasMensualesPorAnio(@Param("anio") int anio);

    @Query("SELECT DAYOFWEEK(a.fecha), COUNT(a) FROM asistencia a WHERE a.fecha >= :desde AND a.fecha <= :hasta GROUP BY DAYOFWEEK(a.fecha) ORDER BY DAYOFWEEK(a.fecha)")
    List<Object[]> asistenciasPorDiaSemana(@Param("desde") LocalDate desde, @Param("hasta") LocalDate hasta);
}
