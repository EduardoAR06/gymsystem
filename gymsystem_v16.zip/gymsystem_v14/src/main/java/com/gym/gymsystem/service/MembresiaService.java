package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.MembresiaAdapter;
import com.gym.gymsystem.entity.CategoriaEntity;
import com.gym.gymsystem.entity.MembresiaEntity;
import com.gym.gymsystem.model.Membresia;
import com.gym.gymsystem.repository.CategoriaRepository;
import com.gym.gymsystem.repository.MembresiaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MembresiaService {
    private final MembresiaRepository repo;
    private final MembresiaAdapter adapter;
    private final CategoriaRepository categoriaRepo;

    public MembresiaService(MembresiaRepository repo, MembresiaAdapter adapter, CategoriaRepository categoriaRepo) {
        this.repo = repo; this.adapter = adapter; this.categoriaRepo = categoriaRepo;
    }

    public List<Membresia> findAll() { return repo.findAll().stream().map(adapter::toModel).collect(Collectors.toList()); }
    public Optional<Membresia> findById(Long id) { return repo.findById(id).map(adapter::toModel); }

    public void save(Membresia m) {
        CategoriaEntity cat = m.getCategoriaId() != null ? categoriaRepo.findById(m.getCategoriaId()).orElse(null) : null;
        repo.save(adapter.toEntity(m, cat));
    }
    public void update(Membresia m) { save(m); }
    public void deleteById(Long id) { repo.deleteById(id); }

    public void actualizarNombreCategoria(Long categoriaId, String nuevoNombre) {
        repo.findAll().stream()
                .filter(e -> e.getCategoria() != null && categoriaId.equals(e.getCategoria().getId()))
                .forEach(repo::save);
    }
}
