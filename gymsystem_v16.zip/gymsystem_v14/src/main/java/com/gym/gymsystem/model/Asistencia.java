package com.gym.gymsystem.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Asistencia {
    private Long id;
    private String trabajador;
    private String dni;
    private LocalDate fecha;
    private LocalTime horaIngreso;
    private LocalTime horaSalida;
    public Asistencia() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTrabajador() { return trabajador; }
    public void setTrabajador(String t) { this.trabajador = t; }
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate f) { this.fecha = f; }
    public LocalTime getHoraIngreso() { return horaIngreso; }
    public void setHoraIngreso(LocalTime h) { this.horaIngreso = h; }
    public LocalTime getHoraSalida() { return horaSalida; }
    public void setHoraSalida(LocalTime h) { this.horaSalida = h; }
}
