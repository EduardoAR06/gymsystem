package com.gym.gymsystem.model;

public class Membresia {
    private Long id;
    private String plan;
    private Double precio;
    private String duracion;
    private Long categoriaId;
    private String categoriaNombre;
    public Membresia() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getPlan() { return plan; }
    public void setPlan(String v) { this.plan = v; }
    public Double getPrecio() { return precio; }
    public void setPrecio(Double v) { this.precio = v; }
    public String getDuracion() { return duracion; }
    public void setDuracion(String v) { this.duracion = v; }
    public Long getCategoriaId() { return categoriaId; }
    public void setCategoriaId(Long v) { this.categoriaId = v; }
    public String getCategoriaNombre() { return categoriaNombre != null ? categoriaNombre : ""; }
    public void setCategoriaNombre(String v) { this.categoriaNombre = v; }
    public String getNombreCompleto() {
        String cat = getCategoriaNombre();
        if (cat != null && !cat.isBlank()) return plan + " " + cat;
        return plan;
    }
}
