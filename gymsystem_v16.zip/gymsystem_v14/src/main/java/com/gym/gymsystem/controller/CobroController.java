package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Cobro;
import com.gym.gymsystem.model.Membresia;
import com.gym.gymsystem.model.Miembro;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.CobroService;
import com.gym.gymsystem.service.MembresiaService;
import com.gym.gymsystem.service.MiembroService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.Optional;

@Controller
@RequestMapping("/cobros")
public class CobroController {

    private final CobroService cobroService;
    private final MiembroService miembroService;
    private final MembresiaService membresiaService;

    public CobroController(CobroService cobroService, MiembroService miembroService, MembresiaService membresiaService) {
        this.cobroService = cobroService;
        this.miembroService = miembroService;
        this.membresiaService = membresiaService;
    }

    private Usuario usuarioORedirect(HttpSession session) {
        return (Usuario) session.getAttribute("usuarioLogueado");
    }

    private void modeloBase(Model model, Usuario u, String q) {
        model.addAttribute("usuario", u);
        model.addAttribute("cobros", cobroService.buscar(q));
        model.addAttribute("miembros", miembroService.findAll());
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("q", q != null ? q : "");
        model.addAttribute("creando", false);
    }

    @GetMapping
    public String listar(Model model, HttpSession session,
                         @RequestParam(value = "q", required = false) String q) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.tienePermiso("COBROS")) return "redirect:/main";
        modeloBase(model, u, q);
        return "cobros/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.tienePermiso("COBROS")) return "redirect:/main";
        modeloBase(model, u, null);
        model.addAttribute("cobro", new Cobro());
        model.addAttribute("creando", true);
        return "cobros/lista";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Cobro cobro, HttpSession session, RedirectAttributes ra) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.tienePermiso("COBROS")) return "redirect:/main";

        cobro.setFecha(LocalDate.now());
        cobro.setEstado("Pagado");

        Optional<Miembro> oMiembro = miembroService.findById(cobro.getMiembroId());
        if (oMiembro.isEmpty()) {
            ra.addFlashAttribute("error", "El cliente seleccionado no existe.");
            return "redirect:/cobros";
        }
        Miembro miembro = oMiembro.get();
        cobro.setMiembroNombre(miembro.getNombres());

        Optional<Membresia> oMembresia = membresiaService.findById(cobro.getMembresiaId());
        if (oMembresia.isEmpty()) {
            ra.addFlashAttribute("error", "La membresia seleccionada no existe.");
            return "redirect:/cobros";
        }
        Membresia membresia = oMembresia.get();

        cobro.setPlanPagado(membresia.getPlan() + " " + membresia.getCategoriaNombre());
        cobro.setMonto(membresia.getPrecio());

        cobroService.save(cobro);

        miembroService.renovarMembresia(miembro.getId(), cobro.getPlanPagado(), membresia.getDuracion());

        ra.addFlashAttribute("mensaje", "Cobro registrado correctamente. Membresia activada.");
        return "redirect:/cobros";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.tienePermiso("COBROS")) return "redirect:/main";
        cobroService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Registro de cobro eliminado.");
        return "redirect:/cobros";
    }
}
