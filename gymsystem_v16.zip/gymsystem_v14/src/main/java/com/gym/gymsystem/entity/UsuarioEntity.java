package com.gym.gymsystem.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity(name = "usuario")
@Table(name = "usuarios")
public class UsuarioEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false)
    private String username;
    private String password;
    private String rol;
    private String nombres;
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "usuario_permisos", joinColumns = @JoinColumn(name = "usuario_id"))
    @Column(name = "permiso")
    private List<String> permisos = new ArrayList<>();
    public UsuarioEntity() {}
    public UsuarioEntity(String username, String password, String rol, String nombres) {
        this.username = username; this.password = password; this.rol = rol; this.nombres = nombres;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String v) { this.username = v; }
    public String getPassword() { return password; }
    public void setPassword(String v) { this.password = v; }
    public String getRol() { return rol; }
    public void setRol(String v) { this.rol = v; }
    public String getNombres() { return nombres; }
    public void setNombres(String v) { this.nombres = v; }
    public List<String> getPermisos() { return permisos; }
    public void setPermisos(List<String> p) { this.permisos = p != null ? new ArrayList<>(p) : new ArrayList<>(); }
}
