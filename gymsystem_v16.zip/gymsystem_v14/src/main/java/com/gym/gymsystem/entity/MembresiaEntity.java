package com.gym.gymsystem.entity;

import jakarta.persistence.*;

@Entity(name = "membresia")
@Table(name = "membresias")
public class MembresiaEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String plan;
    private Double precio;
    private String duracion;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "categoria_id")
    private CategoriaEntity categoria;
    public MembresiaEntity() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getPlan() { return plan; }
    public void setPlan(String v) { this.plan = v; }
    public Double getPrecio() { return precio; }
    public void setPrecio(Double v) { this.precio = v; }
    public String getDuracion() { return duracion; }
    public void setDuracion(String v) { this.duracion = v; }
    public CategoriaEntity getCategoria() { return categoria; }
    public void setCategoria(CategoriaEntity c) { this.categoria = c; }
}
