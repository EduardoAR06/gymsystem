package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Cobro;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.AsistenciaService;
import com.gym.gymsystem.service.CobroService;
import com.gym.gymsystem.service.MiembroService;
import com.gym.gymsystem.service.PersonalService;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class MetricasController {

    private final CobroService cobroService;
    private final MiembroService miembroService;
    private final AsistenciaService asistenciaService;
    private final PersonalService personalService;

    public MetricasController(CobroService cobroService, MiembroService miembroService,
                              AsistenciaService asistenciaService, PersonalService personalService) {
        this.cobroService = cobroService;
        this.miembroService = miembroService;
        this.asistenciaService = asistenciaService;
        this.personalService = personalService;
    }

    @GetMapping("/metricas")
    public String metricas(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) return "redirect:/";
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        model.addAttribute("usuario", u);

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM");
        LocalDate hoy = LocalDate.now();


        List<Cobro> cobrosRecientes = cobroService.cobrosUltimos7Dias();
        Map<LocalDate, Double> cobrosPorDiaMap = new LinkedHashMap<>();
        for (int i = 6; i >= 0; i--) cobrosPorDiaMap.put(hoy.minusDays(i), 0.0);
        cobrosRecientes.forEach(c -> cobrosPorDiaMap.merge(c.getFecha(),
                c.getMonto() != null ? c.getMonto() : 0.0, Double::sum));
        model.addAttribute("cobros7DiasLabels", cobrosPorDiaMap.keySet().stream()
                .map(d -> "\"" + d.format(fmt) + "\"").collect(Collectors.joining(",")));
        model.addAttribute("cobros7DiasData", cobrosPorDiaMap.values().stream()
                .map(String::valueOf).collect(Collectors.joining(",")));

        List<Object[]> asisRaw = asistenciaService.asistenciasPorDiaUltimos7();
        Map<LocalDate, Long> asisPorDia = new LinkedHashMap<>();
        for (int i = 6; i >= 0; i--) asisPorDia.put(hoy.minusDays(i), 0L);
        asisRaw.forEach(row -> {
            LocalDate fecha = (LocalDate) row[0];
            Long count = (Long) row[1];
            if (asisPorDia.containsKey(fecha)) asisPorDia.put(fecha, count);
        });
        model.addAttribute("asis7DiasLabels", asisPorDia.keySet().stream()
                .map(d -> "\"" + d.format(fmt) + "\"").collect(Collectors.joining(",")));
        model.addAttribute("asis7DiasData", asisPorDia.values().stream()
                .map(String::valueOf).collect(Collectors.joining(",")));

        List<String> membLabels = new ArrayList<>();
        List<Long> membData = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            LocalDate dia = hoy.minusDays(i);
            membLabels.add("\"" + dia.format(fmt) + "\"");
            // Estimación: miembros cuya fecha vencimiento está entre dia y dia+30
            long count = miembroService.findAll().stream()
                    .filter(m -> m.getFechaFinMembresia() != null &&
                            !m.getFechaFinMembresia().toLocalDate().isBefore(dia) &&
                            !m.getFechaFinMembresia().toLocalDate().isAfter(dia.plusDays(30)))
                    .count();
            membData.add(count);
        }
        model.addAttribute("memb7DiasLabels", String.join(",", membLabels));
        model.addAttribute("memb7DiasData", membData.stream().map(String::valueOf).collect(Collectors.joining(",")));

        List<String> semLabels = new ArrayList<>();
        List<Double> semData = new ArrayList<>();
        for (int i = 3; i >= 0; i--) {
            LocalDate fin = hoy.minusDays((long) i * 7);
            LocalDate ini = fin.minusDays(6);
            semLabels.add("\"Sem " + (4 - i) + "\"");
            semData.add(cobroService.totalCobradoEntreFechas(ini, fin));
        }
        model.addAttribute("semLabels", String.join(",", semLabels));
        model.addAttribute("semData", semData.stream().map(String::valueOf).collect(Collectors.joining(",")));

        List<Object[]> porPlan = cobroService.cobrosPorPlan();
        model.addAttribute("planLabels", porPlan.stream()
                .map(r -> "\"" + r[0] + "\"").collect(Collectors.joining(",")));
        model.addAttribute("planData", porPlan.stream()
                .map(r -> String.valueOf(r[1])).collect(Collectors.joining(",")));

        model.addAttribute("totalMiembros", miembroService.countTotal());
        model.addAttribute("miembrosActivos", miembroService.countActivos());
        model.addAttribute("totalRecaudado", String.format("%.2f", cobroService.totalCobrado()));
        model.addAttribute("totalPersonal", personalService.countTotal());
        model.addAttribute("totalAsistencias", asistenciaService.countTotal());

        // Cobros por metodo de pago (para gráfico de dona)
        List<Object[]> porMetodo = cobroService.cobrosPorMetodoPago();
        model.addAttribute("metodoLabels", porMetodo.stream()
                .map(r -> "\"" + r[0] + "\"").collect(Collectors.joining(",")));
        model.addAttribute("metodoData", porMetodo.stream()
                .map(r -> String.valueOf(r[1])).collect(Collectors.joining(",")));

        return "metricas";
    }
}