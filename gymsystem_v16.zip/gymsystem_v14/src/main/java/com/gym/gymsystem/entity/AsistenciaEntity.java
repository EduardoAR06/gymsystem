package com.gym.gymsystem.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity(name = "asistencia")
@Table(name = "asistencias")
public class AsistenciaEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String trabajador;
    @Column(length = 20)
    private String dni;
    private LocalDate fecha;
    private LocalTime horaIngreso;
    private LocalTime horaSalida;
    public AsistenciaEntity() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTrabajador() { return trabajador; }
    public void setTrabajador(String t) { this.trabajador = t; }
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate f) { this.fecha = f; }
    public LocalTime getHoraIngreso() { return horaIngreso; }
    public void setHoraIngreso(LocalTime h) { this.horaIngreso = h; }
    public LocalTime getHoraSalida() { return horaSalida; }
    public void setHoraSalida(LocalTime h) { this.horaSalida = h; }
}
