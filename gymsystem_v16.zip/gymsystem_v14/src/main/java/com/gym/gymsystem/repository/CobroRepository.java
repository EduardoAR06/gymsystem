package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.CobroEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface CobroRepository extends JpaRepository<CobroEntity, Long> {
    List<CobroEntity> findByMiembroIdOrderByFechaDesc(Long miembroId);

    @Query("SELECT COALESCE(SUM(c.monto), 0) FROM cobro c WHERE c.estado = 'Pagado'")
    Double sumTotalCobrado();

    @Query("SELECT COALESCE(SUM(c.monto), 0) FROM cobro c WHERE c.estado = 'Pagado' AND c.fecha >= :desde AND c.fecha <= :hasta")
    Double sumCobradoEntreFechas(@Param("desde") LocalDate desde, @Param("hasta") LocalDate hasta);

    @Query("SELECT c.planPagado, COUNT(c) FROM cobro c GROUP BY c.planPagado")
    List<Object[]> countByPlan();

    @Query("SELECT c.metodoPago, COUNT(c) FROM cobro c GROUP BY c.metodoPago")
    List<Object[]> countByMetodoPago();

    List<CobroEntity> findByFechaBetweenOrderByFechaAsc(LocalDate desde, LocalDate hasta);

    @Query("SELECT MONTH(c.fecha), COALESCE(SUM(c.monto), 0) FROM cobro c WHERE YEAR(c.fecha) = :anio AND c.estado = 'Pagado' GROUP BY MONTH(c.fecha) ORDER BY MONTH(c.fecha)")
    List<Object[]> ingresosMensualesPorAnio(@Param("anio") int anio);
}
