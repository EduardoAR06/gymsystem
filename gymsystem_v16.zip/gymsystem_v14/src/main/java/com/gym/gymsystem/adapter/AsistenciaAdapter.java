package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.AsistenciaEntity;
import com.gym.gymsystem.model.Asistencia;
import org.springframework.stereotype.Component;

@Component
public class AsistenciaAdapter {
    public Asistencia toModel(AsistenciaEntity e) {
        if (e == null) return null;
        Asistencia m = new Asistencia();
        m.setId(e.getId());
        m.setTrabajador(e.getTrabajador());
        m.setDni(e.getDni());
        m.setFecha(e.getFecha());
        m.setHoraIngreso(e.getHoraIngreso());
        m.setHoraSalida(e.getHoraSalida());
        return m;
    }
    public AsistenciaEntity toEntity(Asistencia m) {
        if (m == null) return null;
        AsistenciaEntity e = new AsistenciaEntity();
        e.setId(m.getId());
        e.setTrabajador(m.getTrabajador());
        e.setDni(m.getDni());
        e.setFecha(m.getFecha());
        e.setHoraIngreso(m.getHoraIngreso());
        e.setHoraSalida(m.getHoraSalida());
        return e;
    }
}
