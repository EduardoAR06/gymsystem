package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Membresia;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.CategoriaService;
import com.gym.gymsystem.service.MembresiaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/membresias")
public class MembresiaController {

    private final MembresiaService membresiaService;
    private final CategoriaService categoriaService;

    public MembresiaController(MembresiaService membresiaService, CategoriaService categoriaService) {
        this.membresiaService = membresiaService;
        this.categoriaService = categoriaService;
    }

    private Usuario usuarioORedirect(HttpSession session) {
        return (Usuario) session.getAttribute("usuarioLogueado");
    }

    private void modeloBase(Model model, Usuario u) {
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("categorias", categoriaService.findAll());
        model.addAttribute("usuario", u);
        model.addAttribute("membresia", new Membresia());
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        modeloBase(model, u);
        return "membresias/lista";
    }

    @GetMapping("/nueva")
    public String nuevaForm(Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        modeloBase(model, u);
        model.addAttribute("creando", true);
        return "membresias/lista";
    }

    private static final java.util.List<String> UNIDADES_VALIDAS =
            java.util.List.of("minutos", "horas", "dias", "semanas", "meses");

    private String parseDuracion(String valorStr, String unidad, RedirectAttributes ra) {
        if (unidad == null || !UNIDADES_VALIDAS.contains(unidad.toLowerCase())) {
            ra.addFlashAttribute("error", "Unidad de duración inválida.");
            return null;
        }
        int valor;
        try {
            valor = Integer.parseInt(valorStr.trim());
        } catch (NumberFormatException e) {
            ra.addFlashAttribute("error", "La duración debe ser un número entero.");
            return null;
        }
        if (valor <= 0) {
            ra.addFlashAttribute("error", "La duración debe ser mayor a 0.");
            return null;
        }
        return valor + " " + unidad.toLowerCase();
    }

    @PostMapping("/guardar")
    public String guardar(@RequestParam String plan,
                          @RequestParam Double precio,
                          @RequestParam String duracionValor,
                          @RequestParam String duracionUnidad,
                          @RequestParam Long categoriaId,
                          RedirectAttributes ra) {
        String duracion = parseDuracion(duracionValor, duracionUnidad, ra);
        if (duracion == null) return "redirect:/membresias/nueva";
        Membresia m = new Membresia();
        m.setPlan(plan);
        m.setPrecio(precio);
        m.setDuracion(duracion);
        m.setCategoriaId(categoriaId);
        categoriaService.findById(categoriaId).ifPresent(c -> m.setCategoriaNombre(c.getNombre()));
        membresiaService.save(m);
        ra.addFlashAttribute("mensaje", "Membresía creada correctamente.");
        return "redirect:/membresias";
    }

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        Membresia m = membresiaService.findById(id)
                .orElseThrow(() -> new RuntimeException("Membresía no encontrada: " + id));
        modeloBase(model, u);
        model.addAttribute("membresia", m);
        model.addAttribute("editando", true);
        return "membresias/lista";
    }

    @PostMapping("/actualizar")
    public String actualizar(@RequestParam Long id,
                             @RequestParam String plan,
                             @RequestParam Double precio,
                             @RequestParam String duracionValor,
                             @RequestParam String duracionUnidad,
                             @RequestParam Long categoriaId,
                             RedirectAttributes ra) {
        String duracion = parseDuracion(duracionValor, duracionUnidad, ra);
        if (duracion == null) return "redirect:/membresias/editar/" + id;
        Membresia m = membresiaService.findById(id)
                .orElseThrow(() -> new RuntimeException("Membresía no encontrada: " + id));
        m.setPlan(plan);
        m.setPrecio(precio);
        m.setDuracion(duracion);
        m.setCategoriaId(categoriaId);
        categoriaService.findById(categoriaId).ifPresent(c -> m.setCategoriaNombre(c.getNombre()));
        membresiaService.update(m);
        ra.addFlashAttribute("mensaje", "Membresía actualizada correctamente.");
        return "redirect:/membresias";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        membresiaService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Membresía eliminada.");
        return "redirect:/membresias";
    }
}
