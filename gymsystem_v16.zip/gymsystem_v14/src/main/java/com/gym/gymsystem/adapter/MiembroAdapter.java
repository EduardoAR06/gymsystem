package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.MiembroEntity;
import com.gym.gymsystem.model.Miembro;
import org.springframework.stereotype.Component;

@Component
public class MiembroAdapter {

    public Miembro toModel(MiembroEntity entity) {
        if (entity == null) return null;
        Miembro m = new Miembro();
        m.setId(entity.getId());
        m.setNombres(entity.getNombres());
        m.setDni(entity.getDni());
        m.setTelefono(entity.getTelefono());
        m.setMembresia(entity.getMembresia());
        m.setEstado(entity.getEstado());
        m.setDiasRestantes(entity.getDiasRestantes());
        m.setFechaInicioMembresia(entity.getFechaInicioMembresia());
        m.setFechaFinMembresia(entity.getFechaFinMembresia());
        return m;
    }

    public MiembroEntity toEntity(Miembro m) {
        if (m == null) return null;
        MiembroEntity entity = new MiembroEntity();
        entity.setId(m.getId());
        entity.setNombres(m.getNombres());
        entity.setDni(m.getDni());
        entity.setTelefono(m.getTelefono());
        entity.setMembresia(m.getMembresia());
        entity.setEstado(m.getEstado());
        entity.setDiasRestantes(m.getDiasRestantes());
        entity.setFechaInicioMembresia(m.getFechaInicioMembresia());
        entity.setFechaFinMembresia(m.getFechaFinMembresia());
        return entity;
    }
}