package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.PersonalEntity;
import com.gym.gymsystem.model.Personal;
import org.springframework.stereotype.Component;

@Component
public class PersonalAdapter {
    public Personal toModel(PersonalEntity e) {
        if (e == null) return null;
        Personal m = new Personal();
        m.setId(e.getId());
        m.setNombres(e.getNombres());
        m.setDni(e.getDni());
        m.setCargo(e.getCargo());
        m.setTurno(e.getTurno());
        return m;
    }
    public PersonalEntity toEntity(Personal m) {
        if (m == null) return null;
        PersonalEntity e = new PersonalEntity();
        e.setId(m.getId());
        e.setNombres(m.getNombres());
        e.setDni(m.getDni());
        e.setCargo(m.getCargo());
        e.setTurno(m.getTurno());
        return e;
    }
}
