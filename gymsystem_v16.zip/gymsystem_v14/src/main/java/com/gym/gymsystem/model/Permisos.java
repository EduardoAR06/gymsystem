package com.gym.gymsystem.model;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public final class Permisos {
    public static final String ALL = "ALL";

    public static final String INICIO = "INICIO";
    public static final String PUBLICIDAD = "PUBLICIDAD";
    public static final String CONTACTO = "CONTACTO";
    public static final String MIEMBROS = "MIEMBROS";
    public static final String CATEGORIAS = "CATEGORIAS";
    public static final String MEMBRESIAS = "MEMBRESIAS";
    public static final String COBROS = "COBROS";
    public static final String PERSONAL = "PERSONAL";
    public static final String PERSONAL_EDIT = "PERSONAL_EDIT";
    public static final String ASISTENCIAS = "ASISTENCIAS";
    public static final String ASISTENCIAS_EDIT = "ASISTENCIAS_EDIT";
    public static final String ASISTENCIAS_PROPIAS = "ASISTENCIAS_PROPIAS";
    public static final String GESTION = "GESTION";
    public static final String ROLES = "ROLES";
    public static final String KIOSK = "KIOSK";

    private Permisos() {}

    public static Map<String, String> catalogo() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put(INICIO, "Inicio");
        m.put(PUBLICIDAD, "Publicidad");
        m.put(CONTACTO, "Contacto");
        m.put(MIEMBROS, "Clientes");
        m.put(CATEGORIAS, "Categorías de membresía");
        m.put(MEMBRESIAS, "Planes de membresía");
        m.put(COBROS, "Cobros");
        m.put(PERSONAL, "Personal (consulta)");
        m.put(PERSONAL_EDIT, "Personal (edición)");
        m.put(ASISTENCIAS, "Asistencias (historial completo)");
        m.put(ASISTENCIAS_EDIT, "Asistencias (editar registros)");
        m.put(ASISTENCIAS_PROPIAS, "Mi asistencia (solo historial propio)");
        m.put(GESTION, "Panel general");
        m.put(ROLES, "Gestión de roles");
        m.put(KIOSK, "Terminal táctil de asistencias");
        return m;
    }

    public static List<String> todos() {
        return List.copyOf(catalogo().keySet());
    }
}
