package com.gym.gymsystem.config;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public String handleError(Exception ex, Model model, HttpServletRequest request) {
        model.addAttribute("errorMessage", ex.getMessage() != null ? ex.getMessage() : ex.getClass().getName());
        model.addAttribute("errorType", ex.getClass().getSimpleName());
        model.addAttribute("errorCause", ex.getCause() != null ? ex.getCause().getMessage() : "sin causa adicional");
        model.addAttribute("requestUrl", request.getRequestURI());
        return "error";
    }
}
