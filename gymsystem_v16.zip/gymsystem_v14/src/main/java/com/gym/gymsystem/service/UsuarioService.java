package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.UsuarioAdapter;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UsuarioService {
    private final UsuarioRepository repo;
    private final UsuarioAdapter adapter;
    public UsuarioService(UsuarioRepository repo, UsuarioAdapter adapter) { this.repo = repo; this.adapter = adapter; }

    public List<Usuario> findAll() { return repo.findAll().stream().map(adapter::toModel).collect(Collectors.toList()); }
    public Optional<Usuario> findById(Long id) { return repo.findById(id).map(adapter::toModel); }
    public Optional<Usuario> findByUsername(String username) { return repo.findByUsername(username).map(adapter::toModel); }
    public void save(Usuario m) { repo.save(adapter.toEntity(m)); }
    public void update(Usuario m) { repo.save(adapter.toEntity(m)); }
    public void deleteById(Long id) { repo.deleteById(id); }
    public boolean existeUsername(String username) { return repo.findByUsername(username).isPresent(); }
    public Optional<Usuario> login(String username, String password) {
        return repo.findByUsername(username)
                .filter(e -> password != null && password.equals(e.getPassword()))
                .map(adapter::toModel);
    }
}
