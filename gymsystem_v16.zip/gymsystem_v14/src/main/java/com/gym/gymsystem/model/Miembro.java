package com.gym.gymsystem.model;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class Miembro {

    private Long id;
    private String nombres;
    private String dni;
    private String telefono;
    private String membresia;
    private String estado;
    private int diasRestantes;
    private LocalDateTime fechaInicioMembresia;
    private LocalDateTime fechaFinMembresia;

    public Miembro() {}

    public void actualizarEstado() {
        if (membresia == null || membresia.isBlank()) {
            this.diasRestantes = 0;
            this.estado = "Pendiente";
            return;
        }
        if (fechaFinMembresia != null) {
            LocalDateTime ahora = LocalDateTime.now();
            long dias = ChronoUnit.DAYS.between(ahora, fechaFinMembresia);
            this.diasRestantes = (int) Math.max(0, dias);
        }
        this.estado = (diasRestantes > 0 || tieneMinutosRestantes()) ? "Activo" : "Inactivo";
    }

    private boolean tieneMinutosRestantes() {
        if (fechaFinMembresia == null) return false;
        return LocalDateTime.now().isBefore(fechaFinMembresia);
    }

    public String obtenerTiempoRestanteTexto() {
        if (fechaFinMembresia == null) return "Membresia expirada";

        LocalDateTime ahora = LocalDateTime.now();
        if (!ahora.isBefore(fechaFinMembresia)) return "Membresia expirada";

        long dias = ChronoUnit.DAYS.between(ahora, fechaFinMembresia);
        if (dias >= 1) return dias + " dias restantes";

        long horas = ChronoUnit.HOURS.between(ahora, fechaFinMembresia);
        if (horas >= 1) return horas + " horas restantes";

        long minutos = ChronoUnit.MINUTES.between(ahora, fechaFinMembresia);
        return minutos + " minutos restantes";
    }

    public static LocalDateTime calcularFechaFin(LocalDateTime base, String duracion) {
        if (duracion == null || duracion.isBlank()) return base.plusDays(30);

        String lower = duracion.toLowerCase();

        if (lower.contains("minuto") || lower.contains("minutos")) {
            long cantidad = extraerNumero(duracion, 1L);
            return base.plusMinutes(cantidad);
        }

        if (lower.contains("dia") || lower.contains("dias")
                || lower.contains("día") || lower.contains("días")) {
            long cantidad = extraerNumero(duracion, 30L);
            return base.plusDays(cantidad);
        }

        long cantidad = extraerNumero(duracion, 30L);
        return base.plusDays(cantidad);
    }

    private static long extraerNumero(String texto, long valorDefecto) {
        String soloDigitos = texto.replaceAll("[^0-9]", "").trim();
        if (soloDigitos.isEmpty()) return valorDefecto;
        try {
            return Long.parseLong(soloDigitos);
        } catch (NumberFormatException ex) {
            return valorDefecto;
        }
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombres() { return nombres; }
    public void setNombres(String v) { this.nombres = v; }

    public String getDni() { return dni; }
    public void setDni(String v) { this.dni = v; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String v) { this.telefono = v; }

    public String getMembresia() { return membresia; }
    public void setMembresia(String v) { this.membresia = v; }

    public String getEstado() { return estado; }
    public void setEstado(String v) { this.estado = v; }

    public int getDiasRestantes() { return diasRestantes; }
    public void setDiasRestantes(int v) { this.diasRestantes = v; }

    public LocalDateTime getFechaInicioMembresia() { return fechaInicioMembresia; }
    public void setFechaInicioMembresia(LocalDateTime v) { this.fechaInicioMembresia = v; }

    public LocalDateTime getFechaFinMembresia() { return fechaFinMembresia; }
    public void setFechaFinMembresia(LocalDateTime v) { this.fechaFinMembresia = v; }
}