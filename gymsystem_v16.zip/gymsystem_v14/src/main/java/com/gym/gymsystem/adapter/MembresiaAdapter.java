package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.MembresiaEntity;
import com.gym.gymsystem.model.Membresia;
import org.springframework.stereotype.Component;

@Component
public class MembresiaAdapter {
    public Membresia toModel(MembresiaEntity e) {
        if (e == null) return null;
        Membresia m = new Membresia();
        m.setId(e.getId());
        m.setPlan(e.getPlan());
        m.setPrecio(e.getPrecio());
        m.setDuracion(e.getDuracion());
        if (e.getCategoria() != null) {
            m.setCategoriaId(e.getCategoria().getId());
            m.setCategoriaNombre(e.getCategoria().getNombre());
        }
        return m;
    }
    public MembresiaEntity toEntity(Membresia m, com.gym.gymsystem.entity.CategoriaEntity cat) {
        if (m == null) return null;
        MembresiaEntity e = new MembresiaEntity();
        e.setId(m.getId());
        e.setPlan(m.getPlan());
        e.setPrecio(m.getPrecio());
        e.setDuracion(m.getDuracion());
        e.setCategoria(cat);
        return e;
    }
}
