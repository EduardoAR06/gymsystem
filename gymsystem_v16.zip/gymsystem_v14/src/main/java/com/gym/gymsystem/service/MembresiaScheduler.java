package com.gym.gymsystem.service;

import com.gym.gymsystem.model.Miembro;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class MembresiaScheduler {

    private final MiembroService miembroService;

    public MembresiaScheduler(MiembroService miembroService) {
        this.miembroService = miembroService;
    }

    @Scheduled(cron = "0 * * * * *")
    public void verificarMembresiasExpiradas() {
        

        List<Miembro> todos = miembroService.findAll();
        LocalDateTime ahora = LocalDateTime.now();
        int expiradosContados = 0;

        for (Miembro m : todos) {
            if ("Activo".equalsIgnoreCase(m.getEstado()) && m.getFechaFinMembresia() != null) {
                if (ahora.isAfter(m.getFechaFinMembresia())) {
                    m.setEstado("Inactivo");
                    miembroService.update(m);
                    expiradosContados++;

                }
            }
        }


    }
}