package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.CobroEntity;
import com.gym.gymsystem.model.Cobro;
import org.springframework.stereotype.Component;

@Component
public class CobroAdapter {

    public Cobro toModel(CobroEntity entity) {
        if (entity == null) return null;
        Cobro m = new Cobro();
        m.setId(entity.getId());
        m.setMiembroId(entity.getMiembroId());
        m.setMembresiaId(entity.getMembresiaId());
        m.setMiembroNombre(entity.getMiembroNombre());
        m.setPlanPagado(entity.getPlanPagado());
        m.setMonto(entity.getMonto());
        m.setMetodoPago(entity.getMetodoPago());
        m.setEstado(entity.getEstado());
        m.setFecha(entity.getFecha());
        return m;
    }

    public CobroEntity toEntity(Cobro m) {
        if (m == null) return null;
        CobroEntity entity = new CobroEntity();
        entity.setId(m.getId());
        entity.setMiembroId(m.getMiembroId());
        entity.setMembresiaId(m.getMembresiaId());
        entity.setMiembroNombre(m.getMiembroNombre());
        entity.setPlanPagado(m.getPlanPagado());
        entity.setMonto(m.getMonto());
        entity.setMetodoPago(m.getMetodoPago());
        entity.setEstado(m.getEstado());
        entity.setFecha(m.getFecha());
        return entity;
    }
}