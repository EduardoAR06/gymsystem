package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.RolSistemaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface RolSistemaRepository extends JpaRepository<RolSistemaEntity, Long> {
    Optional<RolSistemaEntity> findByCodigo(String codigo);
}
