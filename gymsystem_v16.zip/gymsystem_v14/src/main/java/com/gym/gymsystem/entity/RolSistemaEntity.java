package com.gym.gymsystem.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity(name = "rolSistema")
@Table(name = "roles_sistema")
public class RolSistemaEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false)
    private String codigo;
    private String nombre;
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "rol_permisos", joinColumns = @JoinColumn(name = "rol_id"))
    @Column(name = "permiso")
    private List<String> permisos = new ArrayList<>();
    private boolean sistema;
    public RolSistemaEntity() {}
    public RolSistemaEntity(String codigo, String nombre, List<String> permisos, boolean sistema) {
        this.codigo = codigo; this.nombre = nombre;
        this.permisos = permisos != null ? new ArrayList<>(permisos) : new ArrayList<>();
        this.sistema = sistema;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String v) { this.codigo = v; }
    public String getNombre() { return nombre; }
    public void setNombre(String v) { this.nombre = v; }
    public List<String> getPermisos() { return permisos; }
    public void setPermisos(List<String> p) { this.permisos = p != null ? new ArrayList<>(p) : new ArrayList<>(); }
    public boolean isSistema() { return sistema; }
    public void setSistema(boolean v) { this.sistema = v; }
}
