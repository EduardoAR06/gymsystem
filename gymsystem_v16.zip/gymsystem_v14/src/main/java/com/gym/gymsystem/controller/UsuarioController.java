package com.gym.gymsystem.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class UsuarioController {

    @GetMapping("/usuarios")
    public String redirectRoles() {
        return "redirect:/roles";
    }
}
