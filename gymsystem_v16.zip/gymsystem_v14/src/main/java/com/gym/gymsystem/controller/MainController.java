package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.repository.AsistenciaRepository;
import com.gym.gymsystem.repository.CobroRepository;
import com.gym.gymsystem.repository.MiembroRepository;
import com.gym.gymsystem.service.AsistenciaService;
import com.gym.gymsystem.service.CobroService;
import com.gym.gymsystem.service.MiembroService;
import com.gym.gymsystem.service.PersonalService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class MainController {

    private final MiembroService miembroService;
    private final CobroService cobroService;
    private final PersonalService personalService;
    private final AsistenciaService asistenciaService;
    private final CobroRepository cobroRepository;
    private final MiembroRepository miembroRepository;
    private final AsistenciaRepository asistenciaRepository;

    public MainController(MiembroService miembroService, CobroService cobroService,
                          PersonalService personalService, AsistenciaService asistenciaService,
                          CobroRepository cobroRepository, MiembroRepository miembroRepository,
                          AsistenciaRepository asistenciaRepository) {
        this.miembroService = miembroService;
        this.cobroService = cobroService;
        this.personalService = personalService;
        this.asistenciaService = asistenciaService;
        this.cobroRepository = cobroRepository;
        this.miembroRepository = miembroRepository;
        this.asistenciaRepository = asistenciaRepository;
    }

    @GetMapping("/main")
    public String main(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) return "redirect:/";
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        model.addAttribute("usuario", u);
        model.addAttribute("totalMiembros", miembroService.countTotal());
        model.addAttribute("miembrosActivos", miembroService.countActivos());
        model.addAttribute("totalCobros", cobroService.totalCobrado());
        model.addAttribute("totalAsistencias", asistenciaService.countTotal());
        return "main";
    }

    @GetMapping("/gestion")
    public String gestion(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) return "redirect:/";
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (!u.puedeGestion()) return "redirect:/main";

        int anio = LocalDate.now().getYear();
        String[] meses = {"Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"};

        model.addAttribute("usuario", u);
        model.addAttribute("totalMiembros", miembroService.countTotal());
        model.addAttribute("miembrosActivos", miembroService.countActivos());
        model.addAttribute("totalCobros", cobroService.totalCobrado());
        model.addAttribute("totalPersonal", personalService.countTotal());
        model.addAttribute("totalAsistencias", asistenciaService.countTotal());

        double[] ingresos = new double[12];
        for (Object[] row : cobroRepository.ingresosMensualesPorAnio(anio)) {
            int mes = ((Number) row[0]).intValue() - 1;
            ingresos[mes] = ((Number) row[1]).doubleValue();
        }
        model.addAttribute("ingresosLabels", buildJsonArray(meses));
        model.addAttribute("ingresosData", buildJsonArrayDoubles(ingresos));

        long[] clientes = new long[12];
        for (Object[] row : miembroRepository.clientesPorMes(anio)) {
            int mes = ((Number) row[0]).intValue() - 1;
            clientes[mes] = ((Number) row[1]).longValue();
        }
        model.addAttribute("clientesLabels", buildJsonArray(meses));
        model.addAttribute("clientesData", buildJsonArrayLongs(clientes));

        long[] asistenciasMes = new long[12];
        for (Object[] row : asistenciaRepository.asistenciasMensualesPorAnio(anio)) {
            int mes = ((Number) row[0]).intValue() - 1;
            asistenciasMes[mes] = ((Number) row[1]).longValue();
        }
        model.addAttribute("asistenciaMesLabels", buildJsonArray(meses));
        model.addAttribute("asistenciaMesData", buildJsonArrayLongs(asistenciasMes));

        List<Object[]> planes = cobroRepository.countByPlan();
        String[] planLabels = planes.stream().map(r -> (String) r[0]).toArray(String[]::new);
        long[] planData = planes.stream().mapToLong(r -> ((Number) r[1]).longValue()).toArray();
        model.addAttribute("planesLabels", buildJsonArray(planLabels));
        model.addAttribute("planesData", buildJsonArrayLongs(planData));

        LocalDate hoy = LocalDate.now();
        LocalDate lunesSemana = hoy.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate domingoSemana = lunesSemana.plusDays(6);
        String[] diasSemana = {"Lun","Mar","Mie","Jue","Vie","Sab","Dom"};
        long[] freqSemana = new long[7];
        for (Object[] row : asistenciaRepository.asistenciasPorDiaSemana(lunesSemana, domingoSemana)) {
            int dow = ((Number) row[0]).intValue();
            int idx = (dow == 1) ? 6 : dow - 2;
            if (idx >= 0 && idx < 7) freqSemana[idx] = ((Number) row[1]).longValue();
        }
        model.addAttribute("semanaLabels", buildJsonArray(diasSemana));
        model.addAttribute("semanaData", buildJsonArrayLongs(freqSemana));

        return "gestion";
    }

    @GetMapping("/contacto")
    public String contacto(Model model, HttpSession session) {
        model.addAttribute("usuario", session.getAttribute("usuarioLogueado"));
        return "contacto";
    }

    @GetMapping("/publicidad")
    public String publicidad(Model model, HttpSession session) {
        model.addAttribute("usuario", session.getAttribute("usuarioLogueado"));
        return "publicidad";
    }

    private String buildJsonArray(String[] values) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) sb.append(",");
            sb.append("\"").append(values[i].replace("\"", "\\\"")).append("\"");
        }
        sb.append("]");
        return sb.toString();
    }

    private String buildJsonArrayDoubles(double[] values) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) sb.append(",");
            sb.append(String.format("%.2f", values[i]));
        }
        sb.append("]");
        return sb.toString();
    }

    private String buildJsonArrayLongs(long[] values) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) sb.append(",");
            sb.append(values[i]);
        }
        sb.append("]");
        return sb.toString();
    }
}
