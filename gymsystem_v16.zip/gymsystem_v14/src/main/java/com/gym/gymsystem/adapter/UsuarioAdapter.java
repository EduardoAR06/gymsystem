package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.UsuarioEntity;
import com.gym.gymsystem.model.Usuario;
import org.springframework.stereotype.Component;

@Component
public class UsuarioAdapter {
    public Usuario toModel(UsuarioEntity e) {
        if (e == null) return null;
        Usuario m = new Usuario();
        m.setId(e.getId());
        m.setUsername(e.getUsername());
        m.setPassword(e.getPassword());
        m.setRol(e.getRol());
        m.setNombres(e.getNombres());
        m.setPermisos(e.getPermisos());
        return m;
    }
    public UsuarioEntity toEntity(Usuario m) {
        if (m == null) return null;
        UsuarioEntity e = new UsuarioEntity();
        e.setId(m.getId());
        e.setUsername(m.getUsername());
        e.setPassword(m.getPassword());
        e.setRol(m.getRol());
        e.setNombres(m.getNombres());
        e.setPermisos(m.getPermisos());
        return e;
    }
}
