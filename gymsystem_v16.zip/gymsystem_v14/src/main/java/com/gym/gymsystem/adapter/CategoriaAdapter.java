package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.CategoriaEntity;
import com.gym.gymsystem.model.Categoria;
import org.springframework.stereotype.Component;

@Component
public class CategoriaAdapter {
    public Categoria toModel(CategoriaEntity e) {
        if (e == null) return null;
        Categoria m = new Categoria();
        m.setId(e.getId());
        m.setNombre(e.getNombre());
        m.setDescripcion(e.getDescripcion());
        return m;
    }
    public CategoriaEntity toEntity(Categoria m) {
        if (m == null) return null;
        CategoriaEntity e = new CategoriaEntity();
        e.setId(m.getId());
        e.setNombre(m.getNombre());
        e.setDescripcion(m.getDescripcion());
        return e;
    }
}
