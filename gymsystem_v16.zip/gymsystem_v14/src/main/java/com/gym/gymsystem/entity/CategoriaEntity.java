package com.gym.gymsystem.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity(name = "categoria")
@Table(name = "categorias")
public class CategoriaEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private String nombre;
    private String descripcion;
    @OneToMany(mappedBy = "categoria")
    private List<MembresiaEntity> membresias;

    public CategoriaEntity() {}
    public CategoriaEntity(Long id, String nombre, String descripcion) {
        this.id = id; this.nombre = nombre; this.descripcion = descripcion;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String n) { this.nombre = n; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String d) { this.descripcion = d; }
}
