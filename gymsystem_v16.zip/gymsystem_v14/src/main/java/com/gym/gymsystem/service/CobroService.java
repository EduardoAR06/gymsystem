package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.CobroAdapter;
import com.gym.gymsystem.model.Cobro;
import com.gym.gymsystem.repository.CobroRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CobroService {
    private final CobroRepository repo;
    private final CobroAdapter adapter;
    public CobroService(CobroRepository repo, CobroAdapter adapter) { this.repo = repo; this.adapter = adapter; }

    public List<Cobro> findAll() { return repo.findAll().stream().map(adapter::toModel).collect(Collectors.toList()); }
    public Optional<Cobro> findById(Long id) { return repo.findById(id).map(adapter::toModel); }
    public List<Cobro> findByMiembroId(Long miembroId) {
        return repo.findByMiembroIdOrderByFechaDesc(miembroId).stream().map(adapter::toModel).collect(Collectors.toList());
    }
    public void save(Cobro m) {
        m.setEstado("Pagado"); m.setFecha(LocalDate.now());
        repo.save(adapter.toEntity(m));
    }
    public void update(Cobro m) { repo.save(adapter.toEntity(m)); }
    public void deleteById(Long id) { repo.deleteById(id); }
    public double totalCobrado() { Double t = repo.sumTotalCobrado(); return t != null ? t : 0.0; }
    public List<Cobro> buscar(String q) {
        if (q == null || q.isBlank()) return findAll();
        String term = q.trim().toLowerCase();
        return findAll().stream()
                .filter(c -> (c.getMiembroNombre() != null && c.getMiembroNombre().toLowerCase().contains(term))
                        || (c.getPlanPagado() != null && c.getPlanPagado().toLowerCase().contains(term))
                        || (c.getMetodoPago() != null && c.getMetodoPago().toLowerCase().contains(term))
                        || (c.getEstado() != null && c.getEstado().toLowerCase().contains(term)))
                .collect(Collectors.toList());
    }
    public List<Cobro> cobrosUltimos7Dias() {
        return repo.findByFechaBetweenOrderByFechaAsc(LocalDate.now().minusDays(6), LocalDate.now())
                .stream().map(adapter::toModel).collect(Collectors.toList());
    }
    public List<Object[]> cobrosPorPlan() { return repo.countByPlan(); }
    public List<Object[]> cobrosPorMetodoPago() { return repo.countByMetodoPago(); }
    public Double totalCobradoEntreFechas(LocalDate desde, LocalDate hasta) {
        Double t = repo.sumCobradoEntreFechas(desde, hasta); return t != null ? t : 0.0;
    }
}
