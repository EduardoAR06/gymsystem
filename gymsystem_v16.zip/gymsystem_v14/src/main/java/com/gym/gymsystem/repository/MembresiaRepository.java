package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.MembresiaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MembresiaRepository extends JpaRepository<MembresiaEntity, Long> {}
