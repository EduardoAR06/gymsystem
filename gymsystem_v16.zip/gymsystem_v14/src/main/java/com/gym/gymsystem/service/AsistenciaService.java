package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.AsistenciaAdapter;
import com.gym.gymsystem.entity.AsistenciaEntity;
import com.gym.gymsystem.model.Asistencia;
import com.gym.gymsystem.repository.AsistenciaRepository;
import org.springframework.stereotype.Service;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AsistenciaService {
    private final AsistenciaRepository repo;
    private final AsistenciaAdapter adapter;

    public AsistenciaService(AsistenciaRepository repo, AsistenciaAdapter adapter) {
        this.repo = repo;
        this.adapter = adapter;
    }

    public List<Asistencia> findAll() {
        return repo.findAll().stream().map(adapter::toModel).collect(Collectors.toList());
    }

    public Optional<Asistencia> findById(Long id) {
        return repo.findById(id).map(adapter::toModel);
    }

    public Asistencia registrarIngreso(String trabajador) {
        return registrarIngreso(trabajador, null);
    }

    public Asistencia registrarIngreso(String trabajador, String dni) {
        AsistenciaEntity e = new AsistenciaEntity();
        e.setTrabajador(trabajador);
        e.setDni(dni);
        e.setFecha(LocalDate.now());
        e.setHoraIngreso(LocalTime.now().withSecond(0).withNano(0));
        return adapter.toModel(repo.save(e));
    }

    public void registrarSalida(Long id) {
        repo.findById(id).ifPresent(e -> {
            e.setHoraSalida(LocalTime.now().withSecond(0).withNano(0));
            repo.save(e);
        });
    }

    public String registrarPorDni(String dni, PersonalService personalService) {
        Optional<com.gym.gymsystem.model.Personal> personalOpt = personalService.findByDni(dni);
        if (personalOpt.isEmpty()) return "ERROR_DNI_NO_ENCONTRADO";

        String nombre = personalOpt.get().getNombres();
        LocalDate hoy = LocalDate.now();
        LocalTime ahora = LocalTime.now().withSecond(0).withNano(0);
        List<AsistenciaEntity> hoyAsistencias = repo.findByDniAndFecha(dni, hoy);

        LocalTime ultimaAccion = hoyAsistencias.stream()
                .flatMap(a -> {
                    java.util.stream.Stream.Builder<LocalTime> sb = java.util.stream.Stream.builder();
                    if (a.getHoraIngreso() != null) sb.accept(a.getHoraIngreso());
                    if (a.getHoraSalida() != null) sb.accept(a.getHoraSalida());
                    return sb.build();
                })
                .max(Comparator.naturalOrder())
                .orElse(null);

        if (ultimaAccion != null) {
            long diffMinutos = Math.abs(Duration.between(ultimaAccion, ahora).toMinutes());
            if (diffMinutos < 2) return "ERROR_MINIMO_TIEMPO";
        }

        AsistenciaEntity abierta = hoyAsistencias.stream()
                .filter(a -> a.getHoraIngreso() != null && a.getHoraSalida() == null)
                .findFirst()
                .orElse(null);

        if (abierta != null) {
            registrarSalida(abierta.getId());
            return "OK_SALIDA:" + nombre;
        }

        registrarIngreso(nombre, dni);
        return "OK_INGRESO:" + nombre;
    }

    public List<Asistencia> buscar(String q, String trabajador) {
        List<AsistenciaEntity> base = (trabajador != null && !trabajador.isBlank())
                ? repo.findByTrabajadorContainingIgnoreCase(trabajador)
                : repo.findAll();
        if (q == null || q.isBlank()) return base.stream().map(adapter::toModel).collect(Collectors.toList());
        String term = q.trim().toLowerCase();
        return base.stream()
                .filter(a -> (a.getTrabajador() != null && a.getTrabajador().toLowerCase().contains(term))
                        || (a.getFecha() != null && a.getFecha().toString().contains(term)))
                .map(adapter::toModel).collect(Collectors.toList());
    }

    public String horasTrabajadas(Asistencia a) {
        if (a.getHoraIngreso() == null || a.getHoraSalida() == null) return "—";
        long minutos = Duration.between(a.getHoraIngreso(), a.getHoraSalida()).toMinutes();
        if (minutos < 0) minutos += 24 * 60;
        long h = minutos / 60;
        long m = minutos % 60;
        return h + "h " + m + "m";
    }

    public boolean esTardanza(Asistencia a, String turno) {
        if (a.getHoraIngreso() == null || turno == null) return false;
        LocalTime limite = switch (turno) {
            case "Manana" -> LocalTime.of(6, 15);
            case "Tarde"  -> LocalTime.of(14, 15);
            case "Noche"  -> LocalTime.of(22, 15);
            default       -> null;
        };
        if (limite == null) return false;
        return a.getHoraIngreso().isAfter(limite);
    }

    public void save(Asistencia m) { repo.save(adapter.toEntity(m)); }
    public void update(Asistencia m) { repo.save(adapter.toEntity(m)); }
    public void deleteById(Long id) { repo.deleteById(id); }
    public long countTotal() { return repo.count(); }

    public List<Asistencia> findByTrabajador(String nombre) {
        return repo.findByTrabajadorContainingIgnoreCase(nombre).stream().map(adapter::toModel).collect(Collectors.toList());
    }

    public List<Object[]> asistenciasPorDiaUltimos7() {
        return repo.countByFechaRecientes(LocalDate.now().minusDays(6));
    }
}
