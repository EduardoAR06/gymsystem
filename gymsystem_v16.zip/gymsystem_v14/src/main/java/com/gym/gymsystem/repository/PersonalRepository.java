package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.PersonalEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PersonalRepository extends JpaRepository<PersonalEntity, Long> {
    Optional<PersonalEntity> findByDni(String dni);
}
