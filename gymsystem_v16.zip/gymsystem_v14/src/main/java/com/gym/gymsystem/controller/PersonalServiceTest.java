/*package com.gym.gymsystem.controller;

import com.gym.gymsystem.adapter.PersonalAdapter;
import com.gym.gymsystem.entity.PersonalEntity;
import com.gym.gymsystem.model.Personal;
import com.gym.gymsystem.repository.PersonalRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class PersonalServiceTest {

    private PersonalService service;
    private PersonalRepository repo;
    private PersonalAdapter adapter;

    @BeforeEach
    void setUp() {
        repo = Mockito.mock(PersonalRepository.class);
        adapter = Mockito.mock(PersonalAdapter.class);
        service = new PersonalService(repo, adapter);
    }

    @Test
    @DisplayName("CREAR: guardar personal interactua con el repositorio")
    void cuandoSeGuardaPersonal_entoncesSeInvocaRepo() {
        Personal nuevo = new Personal(null, "Carlos Quispe", "Entrenador", "Mañana");
        PersonalEntity entity = new PersonalEntity();
        
        when(adapter.toEntity(any(Personal.class))).thenReturn(entity);
        when(repo.save(any(PersonalEntity.class))).thenReturn(entity);

        service.save(nuevo);

        verify(repo, times(1)).save(any(PersonalEntity.class));
    }

    @Test
    @DisplayName("LEER: buscar personal por ID existente retorna el registro")
    void cuandoBuscoPersonalPorIdExistente_entoncesLoEncuentro() {
        PersonalEntity entity = new PersonalEntity();
        entity.setId(1L);
        entity.setNombres("María Condori");
        
        Personal model = new Personal(1L, "María Condori", "Limpieza", "Noche");

        when(repo.findById(1L)).thenReturn(Optional.of(entity));
        when(adapter.toModel(entity)).thenReturn(model);

        Optional<Personal> resultado = service.findById(1L);

        assertTrue(resultado.isPresent());
        assertEquals("María Condori", resultado.get().getNombres());
    }

    @Test
    @DisplayName("LEER: findAll retorna todos los empleados")
    void cuandoHayVariosPersonales_entoncesGetAllRetornaTodos() {
        PersonalEntity entity1 = new PersonalEntity();
        PersonalEntity entity2 = new PersonalEntity();
        
        Personal model1 = new Personal(1L, "Pedro Ramos", "Entrenador", "Mañana");
        Personal model2 = new Personal(2L, "Sofía Aguilar", "Recepcionista", "Tarde");

        when(repo.findAll()).thenReturn(List.of(entity1, entity2));
        when(adapter.toModel(entity1)).thenReturn(model1);
        when(adapter.toModel(entity2)).thenReturn(model2);

        List<Personal> lista = service.findAll();

        assertEquals(2, lista.size());
    }

    @Test
    @DisplayName("ELIMINAR: invoca la eliminacion en el repositorio")
    void cuandoEliminoPersonal_entoncesSeLlamaDelete() {
        doNothing().when(repo).deleteById(1L);

        service.deleteById(1L);

        verify(repo, times(1)).deleteById(1L);
    }
}
*/