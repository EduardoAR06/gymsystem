package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.RolSistemaAdapter;
import com.gym.gymsystem.model.Permisos;
import com.gym.gymsystem.model.RolSistema;
import com.gym.gymsystem.repository.RolSistemaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RolService {
    private final RolSistemaRepository repo;
    private final RolSistemaAdapter adapter;
    public RolService(RolSistemaRepository repo, RolSistemaAdapter adapter) { this.repo = repo; this.adapter = adapter; }

    public List<RolSistema> findAll() { return repo.findAll().stream().map(adapter::toModel).collect(Collectors.toList()); }
    public Optional<RolSistema> findById(Long id) { return repo.findById(id).map(adapter::toModel); }
    public Optional<RolSistema> findByCodigo(String codigo) { return repo.findByCodigo(codigo).map(adapter::toModel); }
    public void save(RolSistema m) { repo.save(adapter.toEntity(m)); }
    public void update(RolSistema m) { repo.save(adapter.toEntity(m)); }
    public void deleteById(Long id) { repo.deleteById(id); }

    public List<String> permisosDeRol(String codigoRol) {
        return repo.findByCodigo(codigoRol).map(e -> e.getPermisos()).orElse(List.of(Permisos.INICIO));
    }
    public String nombreDeRol(String codigoRol) {
        return repo.findByCodigo(codigoRol).map(e -> e.getNombre()).orElse(codigoRol);
    }
    public List<RolSistema> findAsignablesAPersonal() {
        return repo.findAll().stream()
                .filter(e -> !"ADMIN".equals(e.getCodigo()) && !"KIOSK_ASIS".equals(e.getCodigo()))
                .map(adapter::toModel).collect(Collectors.toList());
    }
}
