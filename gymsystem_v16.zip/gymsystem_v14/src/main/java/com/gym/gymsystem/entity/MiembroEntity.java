package com.gym.gymsystem.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Entity(name = "miembro")
@Table(name = "miembros")
public class MiembroEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombres;

    @Column(unique = true)
    private String dni;

    private String telefono;
    private String membresia;
    private String estado;
    private int diasRestantes;

    private LocalDateTime fechaInicioMembresia;
    private LocalDateTime fechaFinMembresia;

    public MiembroEntity() {}

    @Transient
    public String obtenerTiempoRestanteTexto() {
        if (fechaFinMembresia == null) {
            return "Membresía expirada";
        }

        LocalDateTime ahora = LocalDateTime.now();

        if (!ahora.isBefore(fechaFinMembresia)) {
            return "Membresía expirada";
        }

        long dias = ChronoUnit.DAYS.between(ahora, fechaFinMembresia);
        if (dias >= 1) {
            return dias + " días restantes";
        }

        long horas = ChronoUnit.HOURS.between(ahora, fechaFinMembresia);
        if (horas >= 1) {
            return horas + " horas restantes";
        }

        long minutos = ChronoUnit.MINUTES.between(ahora, fechaFinMembresia);
        return minutos + " minutos restantes";
    }


    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombres() { return nombres; }
    public void setNombres(String v) { this.nombres = v; }

    public String getDni() { return dni; }
    public void setDni(String v) { this.dni = v; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String v) { this.telefono = v; }

    public String getMembresia() { return membresia; }
    public void setMembresia(String v) { this.membresia = v; }

    public String getEstado() { return estado; }
    public void setEstado(String v) { this.estado = v; }

    public int getDiasRestantes() { return diasRestantes; }
    public void setDiasRestantes(int v) { this.diasRestantes = v; }

    public LocalDateTime getFechaInicioMembresia() { return fechaInicioMembresia; }
    public void setFechaInicioMembresia(LocalDateTime v) { this.fechaInicioMembresia = v; }

    public LocalDateTime getFechaFinMembresia() { return fechaFinMembresia; }
    public void setFechaFinMembresia(LocalDateTime v) { this.fechaFinMembresia = v; }
}