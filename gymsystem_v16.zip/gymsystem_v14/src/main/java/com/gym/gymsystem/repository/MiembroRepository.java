package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.MiembroEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface MiembroRepository extends JpaRepository<MiembroEntity, Long> {
    @Query("SELECT COUNT(m) FROM miembro m WHERE m.estado = 'Activo'")
    long countActivos();

    List<MiembroEntity> findByMembresia(String membresia);

    Optional<MiembroEntity> findByDni(String dni);

    @Query("SELECT MONTH(m.fechaInicioMembresia), COUNT(m) FROM miembro m WHERE YEAR(m.fechaInicioMembresia) = :anio AND m.fechaInicioMembresia IS NOT NULL GROUP BY MONTH(m.fechaInicioMembresia) ORDER BY MONTH(m.fechaInicioMembresia)")
    List<Object[]> clientesPorMes(@Param("anio") int anio);
}
