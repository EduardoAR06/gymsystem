package com.gym.gymsystem.model;

import java.util.ArrayList;
import java.util.List;

public class RolSistema {
    private Long id;
    private String codigo;
    private String nombre;
    private List<String> permisos = new ArrayList<>();
    private boolean sistema;
    public RolSistema() {}
    public RolSistema(String codigo, String nombre, List<String> permisos, boolean sistema) {
        this.codigo = codigo; this.nombre = nombre;
        this.permisos = permisos != null ? new ArrayList<>(permisos) : new ArrayList<>();
        this.sistema = sistema;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String v) { this.codigo = v; }
    public String getNombre() { return nombre; }
    public void setNombre(String v) { this.nombre = v; }
    public List<String> getPermisos() { return permisos; }
    public void setPermisos(List<String> p) { this.permisos = p != null ? new ArrayList<>(p) : new ArrayList<>(); }
    public boolean isSistema() { return sistema; }
    public void setSistema(boolean v) { this.sistema = v; }
    public boolean tienePermiso(String permiso) {
        if (permisos.contains(Permisos.ALL)) return true;
        return permisos.contains(permiso);
    }
}
