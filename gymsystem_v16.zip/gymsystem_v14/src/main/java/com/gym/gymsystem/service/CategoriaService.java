package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.CategoriaAdapter;
import com.gym.gymsystem.model.Categoria;
import com.gym.gymsystem.repository.CategoriaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoriaService {
    private final CategoriaRepository repo;
    private final CategoriaAdapter adapter;
    public CategoriaService(CategoriaRepository repo, CategoriaAdapter adapter) {
        this.repo = repo; this.adapter = adapter;
    }
    public List<Categoria> findAll() { return repo.findAll().stream().map(adapter::toModel).collect(Collectors.toList()); }
    public Optional<Categoria> findById(Long id) { return repo.findById(id).map(adapter::toModel); }
    public void save(Categoria m) { repo.save(adapter.toEntity(m)); }
    public void update(Categoria m) { repo.save(adapter.toEntity(m)); }
    public void deleteById(Long id) { repo.deleteById(id); }
}
