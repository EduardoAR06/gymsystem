package com.gym.gymsystem.model;

public class Personal {
    private Long id;
    private String nombres;
    private String dni;
    private String cargo;
    private String turno;
    public Personal() {}
    public Personal(String nombres, String dni, String cargo, String turno) {
        this.nombres = nombres; this.dni = dni; this.cargo = cargo; this.turno = turno;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombres() { return nombres; }
    public void setNombres(String v) { this.nombres = v; }
    public String getDni() { return dni; }
    public void setDni(String v) { this.dni = v; }
    public String getCargo() { return cargo; }
    public void setCargo(String v) { this.cargo = v; }
    public String getTurno() { return turno; }
    public void setTurno(String v) { this.turno = v; }
}
