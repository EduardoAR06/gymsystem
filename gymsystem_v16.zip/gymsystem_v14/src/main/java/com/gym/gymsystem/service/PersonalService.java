package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.PersonalAdapter;
import com.gym.gymsystem.model.Personal;
import com.gym.gymsystem.repository.PersonalRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PersonalService {
    private final PersonalRepository repo;
    private final PersonalAdapter adapter;
    public PersonalService(PersonalRepository repo, PersonalAdapter adapter) { this.repo = repo; this.adapter = adapter; }

    public List<Personal> findAll() { return repo.findAll().stream().map(adapter::toModel).collect(Collectors.toList()); }
    public Optional<Personal> findById(Long id) { return repo.findById(id).map(adapter::toModel); }
    public Optional<Personal> findByDni(String dni) { return repo.findByDni(dni).map(adapter::toModel); }
    public List<Personal> buscar(String q) {
        if (q == null || q.isBlank()) return findAll();
        String term = q.trim().toLowerCase();
        return findAll().stream()
                .filter(p -> (p.getNombres() != null && p.getNombres().toLowerCase().contains(term))
                        || (p.getDni() != null && p.getDni().toLowerCase().contains(term))
                        || (p.getCargo() != null && p.getCargo().toLowerCase().contains(term))
                        || (p.getTurno() != null && p.getTurno().toLowerCase().contains(term)))
                .collect(Collectors.toList());
    }
    public void save(Personal m) { repo.save(adapter.toEntity(m)); }
    public void update(Personal m) { repo.save(adapter.toEntity(m)); }
    public void deleteById(Long id) { repo.deleteById(id); }
    public long countTotal() { return repo.count(); }
}
