package com.gym.gymsystem.config;

import com.gym.gymsystem.entity.*;
import com.gym.gymsystem.model.Permisos;
import com.gym.gymsystem.repository.*;
import java.time.LocalDateTime;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Configuration
public class DemoDataLoader {

    @Bean
    CommandLineRunner cargarDatos(
            CategoriaRepository catRepo,
            MembresiaRepository memRepo,
            MiembroRepository mieRepo,
            CobroRepository cobRepo,
            PersonalRepository perRepo,
            AsistenciaRepository asisRepo,
            RolSistemaRepository rolRepo,
            UsuarioRepository usuRepo) {

        return args -> {
            CategoriaEntity estandar = catRepo.save(new CategoriaEntity(null, "Estándar", "Acceso a equipos básicos"));
            CategoriaEntity vip = catRepo.save(new CategoriaEntity(null, "VIP", "Acceso completo + clases grupales"));
            CategoriaEntity premium = catRepo.save(new CategoriaEntity(null, "Premium", "Todo incluido + entrenador personal"));

            MembresiaEntity m1 = new MembresiaEntity();
            m1.setPlan("Mensual");
            m1.setPrecio(80.0);
            m1.setDuracion("30 dias");
            m1.setCategoria(estandar);
            MembresiaEntity m2 = new MembresiaEntity();
            m2.setPlan("Trimestral");
            m2.setPrecio(200.0);
            m2.setDuracion("90 dias");
            m2.setCategoria(estandar);
            MembresiaEntity m3 = new MembresiaEntity();
            m3.setPlan("Mensual");
            m3.setPrecio(120.0);
            m3.setDuracion("30 dias");
            m3.setCategoria(vip);
            MembresiaEntity m4 = new MembresiaEntity();
            m4.setPlan("Anual");
            m4.setPrecio(950.0);
            m4.setDuracion("365 dias");
            m4.setCategoria(premium);
            memRepo.saveAll(List.of(m1, m2, m3, m4));

            LocalDate hoy = LocalDate.now();
            MiembroEntity[] miembros = {
                    crearMiembro("Carlos Quispe Mamani", "12345678", "987654321", "Mensual Estándar", hoy.plusDays(15)),
                    crearMiembro("Ana Torres Lima", "23456789", "976543210", "Trimestral Estándar", hoy.plusDays(45)),
                    crearMiembro("Luis García Flores", "34567890", "965432109", "Mensual VIP", hoy.minusDays(3)),
                    crearMiembro("María Rodríguez Vargas", "45678901", "954321098", "Anual Premium", hoy.plusDays(200)),
                    crearMiembro("Pedro Huanca Cruz", "56789012", "943210987", "Mensual Estándar", hoy.plusDays(7))
            };
            for (MiembroEntity mi : miembros) mieRepo.save(mi);

            String[] planes = {"Mensual Estándar", "Trimestral Estándar", "Mensual VIP", "Anual Premium"};
            double[] montos = {80.0, 200.0, 120.0, 950.0};
            String[] metodos = {"Efectivo", "Tarjeta", "Yape", "Plin"};
            String[] nombres = {"Carlos Quispe", "Ana Torres", "Luis García", "María Rodríguez", "Pedro Huanca"};

            for (int i = 0; i < 12; i++) {
                CobroEntity c = new CobroEntity();
                c.setMiembroId((long) (i % 5) + 1);
                c.setMiembroNombre(nombres[i % nombres.length]);
                c.setPlanPagado(planes[i % planes.length]);
                c.setMonto(montos[i % montos.length]);
                c.setMetodoPago(metodos[i % metodos.length]);
                c.setEstado("Pagado");
                c.setFecha(hoy.minusDays(i % 7));
                cobRepo.save(c);
            }

            perRepo.saveAll(List.of(
                    new PersonalEntity("Jorge Vega Paz", "11111111", "Recepcionista", "Mañana"),
                    new PersonalEntity("Sandra Díaz Luna", "22222222", "Instructora", "Tarde"),
                    new PersonalEntity("Miguel Ríos Soto", "33333333", "Entrenador", "Noche"),
                    new PersonalEntity("Carla Mendoza Ruiz", "44444444", "Nutricionista", "Mañana")
            ));

            String[] trabajadores = {"Jorge Vega Paz", "Sandra Díaz Luna", "Miguel Ríos Soto"};
            for (int i = 0; i < 14; i++) {
                AsistenciaEntity a = new AsistenciaEntity();
                a.setTrabajador(trabajadores[i % trabajadores.length]);
                a.setFecha(hoy.minusDays(i % 7));
                a.setHoraIngreso(LocalTime.of(8 + (i % 3), 0));
                a.setHoraSalida(LocalTime.of(16 + (i % 2), 0));
                asisRepo.save(a);
            }

            RolSistemaEntity admin = new RolSistemaEntity("ADMIN", "Administrador",
                    List.of(Permisos.ALL), true);
            RolSistemaEntity recepMem = new RolSistemaEntity("RECEP_MEM", "Recepcionista Membresías",
                    List.of(Permisos.INICIO, Permisos.MIEMBROS, Permisos.COBROS, Permisos.MEMBRESIAS, Permisos.CATEGORIAS, Permisos.CONTACTO, Permisos.PUBLICIDAD), true);
            RolSistemaEntity recepAsis = new RolSistemaEntity("RECEP_ASIS", "Recepcionista Asistencias",
                    List.of(Permisos.INICIO, Permisos.PERSONAL, Permisos.PERSONAL_EDIT, Permisos.ASISTENCIAS, Permisos.ASISTENCIAS_EDIT, Permisos.KIOSK, Permisos.CONTACTO, Permisos.PUBLICIDAD), true);
            RolSistemaEntity kioskAsis = new RolSistemaEntity("KIOSK_ASIS", "Kiosco Asistencias",
                    List.of(Permisos.KIOSK), true);
            RolSistemaEntity histAsis = new RolSistemaEntity("HIST_ASIS", "Consulta Historial",
                    List.of(Permisos.INICIO, Permisos.ASISTENCIAS), true);
            rolRepo.saveAll(List.of(admin, recepMem, recepAsis, kioskAsis, histAsis));

            UsuarioEntity uAdmin = new UsuarioEntity("admin", "1234", "ADMIN", "Administrador Sistema");
            uAdmin.setPermisos(List.of(Permisos.ALL));
            UsuarioEntity uRecep = new UsuarioEntity("recep", "1234", "RECEP_MEM", "Recepcionista");
            uRecep.setPermisos(List.of(Permisos.INICIO, Permisos.MIEMBROS, Permisos.COBROS, Permisos.MEMBRESIAS, Permisos.CATEGORIAS, Permisos.PUBLICIDAD, Permisos.CONTACTO));
            UsuarioEntity uAsis = new UsuarioEntity("asis", "1234", "RECEP_ASIS", "Recepcionista Asistencias");
            uAsis.setPermisos(List.of(Permisos.INICIO, Permisos.PERSONAL, Permisos.PERSONAL_EDIT, Permisos.ASISTENCIAS, Permisos.ASISTENCIAS_EDIT, Permisos.KIOSK, Permisos.CONTACTO, Permisos.PUBLICIDAD));
            UsuarioEntity uKiosk = new UsuarioEntity("asistencia", "1234", "KIOSK_ASIS", "Terminal Asistencia");
            uKiosk.setPermisos(List.of(Permisos.KIOSK));

            UsuarioEntity uHist = new UsuarioEntity("hist", "1234", "HIST_ASIS", "Consulta Historial");
            uHist.setPermisos(List.of(Permisos.INICIO, Permisos.ASISTENCIAS));

            usuRepo.saveAll(List.of(uAdmin, uRecep, uAsis, uKiosk, uHist));

            System.out.println("Datos de demostracion cargados en base de datos H2.");
        };
    }

    private MiembroEntity crearMiembro(String nombres, String dni, String tel, String membresia, LocalDate vencimiento) {
        MiembroEntity m = new MiembroEntity();
        m.setNombres(nombres);
        m.setDni(dni);
        m.setTelefono(tel);
        m.setMembresia(membresia);
        LocalDateTime fechaInicio = LocalDateTime.now();
        LocalDateTime fechaFin = vencimiento.atTime(23, 59, 59);

        m.setFechaInicioMembresia(fechaInicio);
        m.setFechaFinMembresia(fechaFin);
        long dias = java.time.temporal.ChronoUnit.DAYS.between(fechaInicio, fechaFin);
        m.setDiasRestantes((int) Math.max(0, dias));

        m.setEstado(fechaInicio.isBefore(fechaFin) ? "Activo" : "Inactivo");

        return m;
    }
}
