package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.RolSistemaEntity;
import com.gym.gymsystem.model.RolSistema;
import org.springframework.stereotype.Component;

@Component
public class RolSistemaAdapter {
    public RolSistema toModel(RolSistemaEntity e) {
        if (e == null) return null;
        RolSistema m = new RolSistema();
        m.setId(e.getId());
        m.setCodigo(e.getCodigo());
        m.setNombre(e.getNombre());
        m.setPermisos(e.getPermisos());
        m.setSistema(e.isSistema());
        return m;
    }
    public RolSistemaEntity toEntity(RolSistema m) {
        if (m == null) return null;
        RolSistemaEntity e = new RolSistemaEntity();
        e.setId(m.getId());
        e.setCodigo(m.getCodigo());
        e.setNombre(m.getNombre());
        e.setPermisos(m.getPermisos());
        e.setSistema(m.isSistema());
        return e;
    }
}
