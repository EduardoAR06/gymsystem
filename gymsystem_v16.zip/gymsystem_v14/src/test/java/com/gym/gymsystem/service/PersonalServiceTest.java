/*package com.gym.gymsystem.service;

import com.gym.gymsystem.model.Personal;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class PersonalServiceTest {

    private PersonalService service;

    @BeforeEach
    void setUp() {
        service = new PersonalService();
    }

    // CREATE - Fase 1
    @Test
    @DisplayName("CREAR: guardar personal le asigna un ID positivo")
    void cuandoSeGuardaPersonal_entoncesSeAsignaId() {
        // RED: Sin implementacion save(), la prueba falla, no hay contador
        // GREEN: Agregamos AtomicLong que incrementa en cada llamada
        // REFACTOR: AtomicLong es thread-safe e idiomatico para IDs

        Personal nuevo = new Personal(null, "Carlos Quispe", "Entrenador", "Mañana");
        service.save(nuevo);

        assertNotNull(nuevo.getId(),
                "El ID no debe ser null después de guardar");
        assertTrue(nuevo.getId() > 0,
                "El ID debe ser un número positivo");
    }

    // CREATE - Fase 2
    @Test
    @DisplayName("CREAR: dos empleados guardados reciben IDs diferentes")
    void cuandoSeGuardanDosPersonales_entoncesLosDosIdsSonDistintos() {
        // RED: Ambos reciben ID null o igual
        // GREEN: AtomicLong incrementa en cada llamada
        // REFACTOR: AtomicLong garantiza unicidad en ambiente multi-thread

        Personal p1 = new Personal(null, "Ana Flores", "Recepcionista", "Mañana");
        Personal p2 = new Personal(null, "Luis Huanca", "Instructor", "Tarde");

        service.save(p1);
        service.save(p2);

        assertNotEquals(p1.getId(), p2.getId(),
                "Dos empleados distintos no pueden compartir el mismo ID");
    }

    // READ - Fase 1
    @Test
    @DisplayName("LEER: buscar personal por ID existente retorna el registro")
    void cuandoBuscoPersonalPorIdExistente_entoncesLoEncuentro() {
        // RED: findById() no existe
        // GREEN: Stream filter por ID, retorna Optional
        // REFACTOR: Optional es idioma de Java moderno para valores opcionales

        Personal p = new Personal(null, "María Condori", "Limpieza", "Noche");
        service.save(p);

        Optional<Personal> resultado = service.findById(p.getId());

        assertTrue(resultado.isPresent(),
                "Debe encontrarse el personal guardado");
        assertEquals("María Condori", resultado.get().getNombres());
        assertEquals("Noche", resultado.get().getTurno());
    }

    // READ - Fase 2
    @Test
    @DisplayName("LEER: findAll retorna todos los empleados guardados")
    void cuandoHayVariosPersonales_entoncesGetAllRetornaTodos() {
        // RED: findAll() no existe o retorna lista vacía
        // GREEN: Retorna copia de la lista interna
        // REFACTOR: List.copyOf() proporciona encapsulación defensiva

        service.save(new Personal(null, "Pedro Ramos",   "Entrenador",    "Mañana"));
        service.save(new Personal(null, "Sofía Aguilar", "Recepcionista", "Tarde"));
        service.save(new Personal(null, "Jorge Torres",  "Instructor",    "Noche"));

        List<Personal> lista = service.findAll();

        assertEquals(3, lista.size(),
                "findAll debe retornar los 3 empleados guardados");
    }

    // UPDATE
    @Test
    @DisplayName("ACTUALIZAR: modificar cargo y turno de un empleado existente")
    void cuandoActualizoPersonal_entoncesLosDatosCambian() {
        // RED: Sin implementacion update(), cambios no persisten
        // GREEN: Iteramos lista, encontramos por ID, reemplazamos
        // REFACTOR: Iteracion clara y directa sin cambios de paradigma

        Personal original = new Personal(null, "Rosa Mamani", "Limpieza", "Mañana");
        service.save(original);

        //Personal modificado = new Personal(original.getId(), "Rosa Mamani", "Supervisora", "Tarde");
        //service.update(modificado);

        Optional<Personal> encontrado = service.findById(original.getId());
        assertTrue(encontrado.isPresent());
        assertEquals("Supervisora", encontrado.get().getCargo(),
                "El cargo debe haber cambiado a Supervisora");
        assertEquals("Tarde", encontrado.get().getTurno(),
                "El turno debe haber cambiado a Tarde");
    }
    // DELETE
    @Test
    @DisplayName("ELIMINAR: al borrar empleado ya no aparece en la lista")
    void cuandoEliminoPersonal_entoncesDesapareceDelaLista() {
        // RED: Sin implementacion deleteById(), elemento permanece
        // GREEN: removeIf() elimina el elemento que cumple predicado
        // REFACTOR: Lambda y removeIf() son idiomaticos para esta operacion

        Personal p = new Personal(null, "Julio Perez", "Entrenador", "Mañana");
        service.save(p);
        Long idGuardado = p.getId();

        service.deleteById(idGuardado);

        Optional<Personal> resultado = service.findById(idGuardado);
        assertFalse(resultado.isPresent(),
                "El empleado eliminado no debe encontrarse");

        assertEquals(0, service.findAll().size(),
                "La lista debe quedar vacía tras eliminar el único registro");
    }
}
*/