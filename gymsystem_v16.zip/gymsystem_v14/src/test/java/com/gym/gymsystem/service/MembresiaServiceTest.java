/*package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.MembresiaAdapter;
import com.gym.gymsystem.entity.MembresiaEntity;
import com.gym.gymsystem.model.Membresia;
import com.gym.gymsystem.repository.CategoriaRepository;
import com.gym.gymsystem.repository.MembresiaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class MembresiaServiceTest {

    private MembresiaService service;
    private MembresiaRepository repo;
    private CategoriaRepository catRepo;
    private MembresiaAdapter adapter;

    @BeforeEach
    void setUp() {
        repo = Mockito.mock(MembresiaRepository.class);
        catRepo = Mockito.mock(CategoriaRepository.class);
        adapter = Mockito.mock(MembresiaAdapter.class);
        service = new MembresiaService(repo, catRepo, adapter);
    }

    @Test
    @DisplayName("LEER: buscar todas las membresias de la base de datos")
    void cuandoSeBuscanMembresias_entoncesRetornaLista() {
        MembresiaEntity entity = new MembresiaEntity();
        Membresia model = new Membresia();
        model.setId(1L);
        model.setPlan("Mensual Estándar");

        when(repo.findAll()).thenReturn(List.of(entity));
        when(adapter.toModel(entity)).thenReturn(model);

        List<Membresia> resultado = service.findAll();

        assertFalse(resultado.isEmpty());
        assertEquals(1, resultado.size());
    }

    @Test
    @DisplayName("ELIMINAR: borrar membresia por ID invoca al repositorio")
    void cuandoSeEliminaMembresia_entoncesLlamaAlRepo() {
        doNothing().when(repo).deleteById(1L);

        service.deleteById(1L);

        verify(repo, times(1)).deleteById(1L);
    }
}

 */