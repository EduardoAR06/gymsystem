package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Permisos;
import com.gym.gymsystem.model.RolSistema;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.RolService;
import com.gym.gymsystem.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/roles")
public class RolController {

    private final RolService rolService;
    private final UsuarioService usuarioService;

    public RolController(RolService rolService, UsuarioService usuarioService) {
        this.rolService = rolService;
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeGestionarRoles()) return "redirect:/main";
        model.addAttribute("roles", rolService.findAll());
        model.addAttribute("permisosCatalogo", Permisos.catalogo());
        model.addAttribute("usuario", u);
        return "roles/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null || !u.puedeGestionarRoles()) return "redirect:/roles";
        model.addAttribute("rol", new RolSistema());
        model.addAttribute("permisosCatalogo", Permisos.catalogo());
        model.addAttribute("creando", true);
        model.addAttribute("editando", false);
        model.addAttribute("usuario", u);
        return "roles/form";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null || !u.puedeGestionarRoles()) return "redirect:/roles";
        RolSistema rol = rolService.findById(id).orElseThrow(() -> new RuntimeException("Rol no encontrado"));
        model.addAttribute("rol", rol);
        model.addAttribute("permisosCatalogo", Permisos.catalogo());
        model.addAttribute("editando", true);
        model.addAttribute("creando", false);
        model.addAttribute("usuariosDelRol", usuarioService.findByRol(rol.getCodigo()));
        model.addAttribute("usuario", u);
        return "roles/form";
    }

    @PostMapping("/guardar")
    public String guardar(@RequestParam String nombre,
                          @RequestParam(required = false) String codigo,
                          @RequestParam(required = false) String[] permisosSeleccionados,
                          @RequestParam(required = false) String nuevoUsername,
                          @RequestParam(required = false) String nuevoPassword,
                          @RequestParam(required = false) String nuevoNombres,
                          RedirectAttributes ra) {

        RolSistema rol = new RolSistema();
        rol.setNombre(nombre.trim());
        String codigoFinal = (codigo != null && !codigo.isBlank())
                ? codigo.trim().toUpperCase().replace(" ", "_")
                : "ROL_" + nombre.trim().toUpperCase().replace(" ", "_").replaceAll("[^A-Z0-9_]", "");
        rol.setCodigo(codigoFinal);
        rol.setPermisos(permisosSeleccionados != null ? Arrays.asList(permisosSeleccionados) : List.of());

        if (rol.getPermisos().isEmpty()) {
            ra.addFlashAttribute("error", "Seleccione al menos una interfaz para el rol.");
            return "redirect:/roles/nuevo";
        }

        rolService.save(rol);

        if (nuevoUsername != null && !nuevoUsername.isBlank()) {
            if (usuarioService.existeUsername(nuevoUsername.trim())) {
                ra.addFlashAttribute("error", "Rol creado, pero el nombre de usuario ya existe. Cree el usuario manualmente.");
                return "redirect:/roles";
            }
            if (nuevoPassword == null || nuevoPassword.isBlank()) {
                ra.addFlashAttribute("error", "Rol creado, pero se requiere una contrasena para crear el usuario.");
                return "redirect:/roles";
            }
            Usuario nuevo = new Usuario();
            nuevo.setUsername(nuevoUsername.trim());
            nuevo.setPassword(nuevoPassword.trim());
            nuevo.setRol(codigoFinal);
            nuevo.setNombres(nuevoNombres != null && !nuevoNombres.isBlank() ? nuevoNombres.trim() : nombre.trim());
            nuevo.setPermisos(rol.getPermisos());
            usuarioService.save(nuevo);
            ra.addFlashAttribute("mensaje", "Rol y usuario de acceso creados correctamente.");
        } else {
            ra.addFlashAttribute("mensaje", "Rol creado. Puede asignar usuarios desde esta misma pantalla.");
        }

        return "redirect:/roles";
    }

    @PostMapping("/actualizar")
    public String actualizar(@RequestParam Long id,
                             @RequestParam String nombre,
                             @RequestParam(required = false) String codigo,
                             @RequestParam(required = false) String[] permisosSeleccionados,
                             RedirectAttributes ra) {
        RolSistema rol = rolService.findById(id).orElseThrow();
        rol.setNombre(nombre.trim());
        if (!rol.isSistema() && codigo != null && !codigo.isBlank()) {
            rol.setCodigo(codigo.trim());
        }
        List<String> nuevosPermisos = permisosSeleccionados != null ? Arrays.asList(permisosSeleccionados) : List.of();
        if (nuevosPermisos.isEmpty()) {
            ra.addFlashAttribute("error", "Seleccione al menos una interfaz para el rol.");
            return "redirect:/roles/editar/" + id;
        }
        rol.setPermisos(nuevosPermisos);
        rolService.update(rol);

        for (Usuario u : usuarioService.findByRol(rol.getCodigo())) {
            u.setPermisos(nuevosPermisos);
            usuarioService.update(u);
        }

        ra.addFlashAttribute("mensaje", "Rol actualizado. Los permisos de sus usuarios han sido sincronizados.");
        return "redirect:/roles";
    }

    @PostMapping("/usuarios/agregar")
    public String agregarUsuario(@RequestParam Long rolId,
                                 @RequestParam String username,
                                 @RequestParam String password,
                                 @RequestParam(required = false) String nombres,
                                 RedirectAttributes ra) {
        RolSistema rol = rolService.findById(rolId).orElseThrow();

        if (usuarioService.existeUsername(username.trim())) {
            ra.addFlashAttribute("error", "El nombre de usuario ya existe en el sistema.");
            return "redirect:/roles/editar/" + rolId;
        }
        if (password.isBlank()) {
            ra.addFlashAttribute("error", "La contrasena no puede estar vacia.");
            return "redirect:/roles/editar/" + rolId;
        }

        Usuario nuevo = new Usuario();
        nuevo.setUsername(username.trim());
        nuevo.setPassword(password.trim());
        nuevo.setRol(rol.getCodigo());
        nuevo.setNombres(nombres != null && !nombres.isBlank() ? nombres.trim() : username.trim());
        nuevo.setPermisos(rol.getPermisos());
        usuarioService.save(nuevo);

        ra.addFlashAttribute("mensaje", "Usuario agregado al rol correctamente.");
        return "redirect:/roles/editar/" + rolId;
    }

    @GetMapping("/usuarios/eliminar/{usuarioId}")
    public String eliminarUsuario(@PathVariable Long usuarioId,
                                  @RequestParam Long rolId,
                                  RedirectAttributes ra) {
        usuarioService.deleteById(usuarioId);
        ra.addFlashAttribute("mensaje", "Usuario eliminado del sistema.");
        return "redirect:/roles/editar/" + rolId;
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        RolSistema rol = rolService.findById(id).orElseThrow();
        if (rol.isSistema()) {
            ra.addFlashAttribute("error", "Los roles de sistema no pueden eliminarse.");
            return "redirect:/roles";
        }
        rolService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Rol eliminado.");
        return "redirect:/roles";
    }
}
