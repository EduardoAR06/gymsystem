package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.UsuarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<UsuarioEntity, Long> {
    Optional<UsuarioEntity> findByUsername(String username);
    List<UsuarioEntity> findByRol(String rol);
}
