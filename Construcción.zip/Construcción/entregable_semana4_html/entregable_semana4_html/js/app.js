function mostrarMensaje(texto) {
    alert(texto);
}

function confirmarAccion(texto) {
    return confirm(texto);
}

function generarFilasTabla(tbody, datos, columnas, acciones) {
    tbody.innerHTML = "";

    datos.forEach((item, index) => {
        const fila = document.createElement("tr");

        columnas.forEach((columna) => {
            const celda = document.createElement("td");
            if (typeof columna.render === "function") {
                celda.innerHTML = columna.render(item);
            } else {
                celda.textContent = item[columna.campo];
            }
            fila.appendChild(celda);
        });

        if (acciones) {
            const celdaAcciones = document.createElement("td");

            const botonEditar = document.createElement("button");
            botonEditar.type = "button";
            botonEditar.className = "btn btn-secondary";
            botonEditar.textContent = "Editar";
            botonEditar.addEventListener("click", () => acciones.editar(index));

            const botonEliminar = document.createElement("button");
            botonEliminar.type = "button";
            botonEliminar.className = "btn btn-danger";
            botonEliminar.textContent = "Eliminar";
            botonEliminar.addEventListener("click", () => acciones.eliminar(index));

            celdaAcciones.append(botonEditar, botonEliminar);
            fila.appendChild(celdaAcciones);
        }

        tbody.appendChild(fila);
    });
}

function configurarCrud(config) {
    const formulario = document.getElementById(config.formId);
    const tbody = document.getElementById(config.tbodyId);
    const botonCancelar = document.getElementById(config.cancelButtonId);
    const tituloFormulario = document.getElementById(config.formTitleId);
    const datos = [...config.datosIniciales];
    let indiceEdicion = null;

    const leerFormulario = () => {
        const item = {};
        config.campos.forEach((campo) => {
            item[campo] = formulario.elements[campo].value.trim();
        });
        return item;
    };

    const llenarFormulario = (item) => {
        config.campos.forEach((campo) => {
            formulario.elements[campo].value = item[campo];
        });
    };

    const limpiarFormulario = () => {
        formulario.reset();
        indiceEdicion = null;
        if (tituloFormulario) tituloFormulario.textContent = config.tituloNuevo;
        if (botonCancelar) botonCancelar.hidden = true;
    };

    const renderizar = () => {
        generarFilasTabla(tbody, datos, config.columnas, {
            editar(index) {
                indiceEdicion = index;
                llenarFormulario(datos[index]);
                if (tituloFormulario) tituloFormulario.textContent = config.tituloEditar;
                if (botonCancelar) botonCancelar.hidden = false;
            },
            eliminar(index) {
                if (confirmarAccion(config.mensajeEliminar)) {
                    datos.splice(index, 1);
                    renderizar();
                    limpiarFormulario();
                }
            }
        });
    };

    formulario.addEventListener("submit", (event) => {
        event.preventDefault();

        if (!formulario.checkValidity()) {
            formulario.reportValidity();
            return;
        }

        const item = leerFormulario();
        if (typeof config.validar === "function") {
            const mensaje = config.validar(item);
            if (mensaje) {
                mostrarMensaje(mensaje);
                return;
            }
        }

        if (indiceEdicion === null) {
            datos.push(item);
        } else {
            datos[indiceEdicion] = item;
        }

        renderizar();
        limpiarFormulario();
    });

    if (botonCancelar) {
        botonCancelar.addEventListener("click", limpiarFormulario);
    }

    renderizar();
}

function configurarLogin() {
    const formulario = document.getElementById("login-form");
    const error = document.getElementById("login-error");
    if (!formulario || !error) return;

    formulario.addEventListener("submit", (event) => {
        event.preventDefault();
        const usuario = formulario.elements.usuario.value.trim();
        const password = formulario.elements.password.value.trim();
        const modulo = formulario.elements.modulo.value;

        if (usuario === "admin" && password === "1234") {
            window.location.href = modulo;
            return;
        }

        error.hidden = false;
        error.textContent = "Usuario o contraseña incorrectos.";
    });
}

function inicializarPagina() {
    configurarLogin();

    const pagina = document.body.dataset.page;

    if (pagina === "miembros") {
        configurarCrud({
            formId: "miembro-form",
            tbodyId: "miembros-body",
            cancelButtonId: "cancelar-miembro",
            formTitleId: "miembro-form-title",
            tituloNuevo: "Formulario de miembro",
            tituloEditar: "Editar miembro",
            mensajeEliminar: "¿Eliminar este miembro?",
            campos: ["nombre", "dni", "telefono", "membresia"],
            datosIniciales: [
                { nombre: "Carlos Ramos", dni: "70234561", telefono: "987654321", membresia: "Mensual", estado: "Activo" },
                { nombre: "María Quispe", dni: "71345672", telefono: "986123456", membresia: "Trimestral", estado: "Activo" },
                { nombre: "Jorge Huamán", dni: "72456783", telefono: "985654321", membresia: "Mensual", estado: "Pendiente" }
            ],
            columnas: [
                { campo: "nombre" },
                { campo: "dni" },
                { campo: "telefono" },
                { campo: "membresia" },
                { render: (item) => `<span class="badge ${item.estado === "Pendiente" ? "pending" : ""}">${item.estado}</span>` }
            ]
        });
    }

    if (pagina === "membresias") {
        configurarCrud({
            formId: "membresia-form",
            tbodyId: "membresias-body",
            cancelButtonId: "cancelar-membresia",
            formTitleId: "membresia-form-title",
            tituloNuevo: "Formulario de membresía",
            tituloEditar: "Editar membresía",
            mensajeEliminar: "¿Eliminar esta membresía?",
            campos: ["plan", "precio", "duracion"],
            datosIniciales: [
                { plan: "Mensual", precio: "120.00", duracion: "30" },
                { plan: "Trimestral", precio: "300.00", duracion: "90" },
                { plan: "Personalizado", precio: "180.00", duracion: "30" }
            ],
            columnas: [
                { campo: "plan" },
                { render: (item) => `S/ ${Number(item.precio).toFixed(2)}` },
                { render: (item) => `${item.duracion} días` }
            ]
        });
    }

    if (pagina === "cobros") {
        configurarCrud({
            formId: "cobro-form",
            tbodyId: "cobros-body",
            cancelButtonId: "cancelar-cobro",
            formTitleId: "cobro-form-title",
            tituloNuevo: "Formulario de cobro",
            tituloEditar: "Editar cobro",
            mensajeEliminar: "¿Eliminar este cobro?",
            campos: ["miembro", "monto", "metodo", "estado"],
            datosIniciales: [
                { miembro: "Carlos Ramos", monto: "120.00", metodo: "Efectivo", estado: "Pagado" },
                { miembro: "María Quispe", monto: "300.00", metodo: "Yape", estado: "Pagado" },
                { miembro: "Jorge Huamán", monto: "120.00", metodo: "Tarjeta", estado: "Pendiente" }
            ],
            columnas: [
                { campo: "miembro" },
                { render: (item) => `S/ ${Number(item.monto).toFixed(2)}` },
                { campo: "metodo" },
                { render: (item) => `<span class="badge ${item.estado === "Pendiente" ? "pending" : ""}">${item.estado}</span>` }
            ]
        });
    }

    if (pagina === "personal") {
        configurarCrud({
            formId: "personal-form",
            tbodyId: "personal-body",
            cancelButtonId: "cancelar-personal",
            formTitleId: "personal-form-title",
            tituloNuevo: "Formulario de personal",
            tituloEditar: "Editar personal",
            mensajeEliminar: "¿Eliminar este registro de personal?",
            campos: ["nombre", "cargo", "turno"],
            datosIniciales: [
                { nombre: "Rosa Salazar", cargo: "Recepcionista", turno: "Mañana" },
                { nombre: "Víctor Díaz", cargo: "Entrenador", turno: "Tarde" },
                { nombre: "Elena Soto", cargo: "Limpieza", turno: "Mañana" }
            ],
            columnas: [
                { campo: "nombre" },
                { campo: "cargo" },
                { campo: "turno" }
            ]
        });
    }

    if (pagina === "asistencias") {
        configurarCrud({
            formId: "asistencia-form",
            tbodyId: "asistencias-body",
            cancelButtonId: "cancelar-asistencia",
            formTitleId: "asistencia-form-title",
            tituloNuevo: "Formulario de asistencia",
            tituloEditar: "Editar asistencia",
            mensajeEliminar: "¿Eliminar esta asistencia?",
            campos: ["trabajador", "fecha", "ingreso", "salida"],
            datosIniciales: [
                { trabajador: "Rosa Salazar", fecha: "2026-04-06", ingreso: "07:55", salida: "14:00" },
                { trabajador: "Víctor Díaz", fecha: "2026-04-06", ingreso: "14:05", salida: "21:00" },
                { trabajador: "Elena Soto", fecha: "2026-04-06", ingreso: "08:00", salida: "15:00" }
            ],
            validar(item) {
                if (item.salida <= item.ingreso) {
                    return "La hora de salida debe ser posterior a la hora de ingreso.";
                }
                return "";
            },
            columnas: [
                { campo: "trabajador" },
                { campo: "fecha" },
                { campo: "ingreso" },
                { campo: "salida" }
            ]
        });
    }
}

document.addEventListener("DOMContentLoaded", inicializarPagina);
