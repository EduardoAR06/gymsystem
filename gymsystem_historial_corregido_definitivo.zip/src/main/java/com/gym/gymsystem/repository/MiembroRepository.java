package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.MiembroEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface MiembroRepository extends JpaRepository<MiembroEntity, Long> {
    @Query("SELECT COUNT(m) FROM miembro m WHERE m.estado = 'Activo'")
    long countActivos();
    List<MiembroEntity> findByMembresia(String membresia);
    Optional<MiembroEntity> findByDni(String dni);
}
