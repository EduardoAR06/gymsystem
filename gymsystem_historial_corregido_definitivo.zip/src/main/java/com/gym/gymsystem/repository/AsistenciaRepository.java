package com.gym.gymsystem.repository;

import com.gym.gymsystem.entity.AsistenciaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface AsistenciaRepository extends JpaRepository<AsistenciaEntity, Long> {
    List<AsistenciaEntity> findByTrabajadorContainingIgnoreCase(String nombre);
    List<AsistenciaEntity> findByFechaBetweenOrderByFechaAsc(LocalDate desde, LocalDate hasta);
    List<AsistenciaEntity> findByDniAndFecha(String dni, LocalDate fecha);
    @Query("SELECT a.fecha, COUNT(a) FROM asistencia a WHERE a.fecha >= :desde GROUP BY a.fecha ORDER BY a.fecha ASC")
    List<Object[]> countByFechaRecientes(@Param("desde") LocalDate desde);
}
