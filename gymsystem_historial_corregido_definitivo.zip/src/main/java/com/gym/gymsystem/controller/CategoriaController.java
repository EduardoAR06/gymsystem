package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Categoria;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.CategoriaService;
import com.gym.gymsystem.service.MembresiaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/categorias")
public class CategoriaController {

    private final CategoriaService categoriaService;
    private final MembresiaService membresiaService;

    public CategoriaController(CategoriaService categoriaService,
                                MembresiaService membresiaService) {
        this.categoriaService = categoriaService;
        this.membresiaService = membresiaService;
    }

    private Usuario check(HttpSession session) {
        return (Usuario) session.getAttribute("usuarioLogueado");
    }

    // ── READ ──────────────────────────────────────────────────────────────────

    @GetMapping
    public String listar(Model model, HttpSession session) {
        Usuario u = check(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("categorias", categoriaService.findAll());
        model.addAttribute("categoria",  new Categoria());
        model.addAttribute("usuario",    u);
        return "categorias/lista";
    }

    // ── CREATE ────────────────────────────────────────────────────────────────

    @GetMapping("/nueva")
    public String nuevaForm(Model model, HttpSession session) {
        Usuario u = check(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("categorias", categoriaService.findAll());
        model.addAttribute("categoria",  new Categoria());
        model.addAttribute("creando",    true);
        model.addAttribute("usuario",    u);
        return "categorias/lista";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Categoria categoria, RedirectAttributes ra) {
        categoriaService.save(categoria);
        ra.addFlashAttribute("mensaje", "Categoría creada correctamente.");
        return "redirect:/categorias";
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = check(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("categorias", categoriaService.findAll());
        model.addAttribute("categoria",  categoriaService.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada")));
        model.addAttribute("editando",   true);
        model.addAttribute("usuario",    u);
        return "categorias/lista";
    }

    @PostMapping("/actualizar")
    public String actualizar(@ModelAttribute Categoria categoria, RedirectAttributes ra) {
        categoriaService.update(categoria);
        // Propagar el nuevo nombre a todas las membresías que usen esta categoría
        membresiaService.actualizarNombreCategoria(categoria.getId(), categoria.getNombre());
        ra.addFlashAttribute("mensaje", "Categoría actualizada y membresías sincronizadas.");
        return "redirect:/categorias";
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        Usuario u = check(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        categoriaService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Categoría eliminada.");
        return "redirect:/categorias";
    }
}
