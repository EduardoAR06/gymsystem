package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Asistencia;
import com.gym.gymsystem.model.Personal;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.AsistenciaService;
import com.gym.gymsystem.service.PersonalService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/asistencias")
public class AsistenciaController {

    private final AsistenciaService asistenciaService;
    private final PersonalService personalService;

    public AsistenciaController(AsistenciaService asistenciaService, PersonalService personalService) {
        this.asistenciaService = asistenciaService;
        this.personalService = personalService;
    }

    private Map<String, String> mapaTurnos() {
        Map<String, String> turnos = new HashMap<>();
        personalService.findAll().forEach(p -> turnos.put(p.getNombres(), p.getTurno()));
        return turnos;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q,
                         Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (u.isKioskAsis()) return "redirect:/asistencias/kiosk";
        if (!u.puedeVerAsistencias()) return "redirect:/main";

        model.addAttribute("personales", personalService.findAll());
        model.addAttribute("usuario", u);
        model.addAttribute("turnosPorTrabajador", mapaTurnos());
        model.addAttribute("asSvc", asistenciaService);
        model.addAttribute("q", q != null ? q : "");

        if (u.isPersonal()) {
            String nombreTrabajador = u.getNombres();
            model.addAttribute("modoPersonal", true);
            model.addAttribute("nombreTrabajador", nombreTrabajador);
            model.addAttribute("soloLectura", true);
            model.addAttribute("soloPropio", true);
            model.addAttribute("asistencias", asistenciaService.buscar(q, nombreTrabajador));
        } else if (u.puedeVerHistorialCompletoAsistencias()) {
            model.addAttribute("modoPersonal", false);
            model.addAttribute("soloLectura", !u.puedeEditarAsistencias());
            model.addAttribute("soloPropio", false);
            model.addAttribute("asistencias", asistenciaService.buscar(q, null));
        } else {
            return "redirect:/main";
        }

        return "asistencias/lista";
    }

    /** Terminal táctil — solo cuenta KIOSK_ASIS */
    @GetMapping("/kiosk")
    public String kiosk(HttpSession session, Model model) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.isKioskAsis()) return "redirect:/asistencias";
        model.addAttribute("usuario", u);
        return "asistencias/kiosk";
    }

    @PostMapping("/kiosk/registrar")
    public String kioskRegistrar(@RequestParam String dni,
                                 HttpSession session,
                                 RedirectAttributes ra) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.isKioskAsis()) return "redirect:/asistencias";

        String dniLimpio = dni != null ? dni.trim() : "";
        if (dniLimpio.isBlank()) {
            ra.addFlashAttribute("error", "Ingrese su DNI.");
            return "redirect:/asistencias/kiosk";
        }

        String resultado = asistenciaService.registrarPorDni(dniLimpio, personalService);
        if (resultado.startsWith("OK_INGRESO:")) {
            String nombre = resultado.substring("OK_INGRESO:".length());
            ra.addFlashAttribute("mensaje", "Entrada registrada — " + nombre);
            ra.addFlashAttribute("ultimoTipo", "ingreso");
        } else if (resultado.startsWith("OK_SALIDA:")) {
            String nombre = resultado.substring("OK_SALIDA:".length());
            ra.addFlashAttribute("mensaje", "Salida registrada — " + nombre);
            ra.addFlashAttribute("ultimoTipo", "salida");
        } else if (resultado.equals("ERROR_DNI_NO_ENCONTRADO")) {
            ra.addFlashAttribute("error", "DNI no registrado en el personal del gimnasio.");
        } else if (resultado.startsWith("ERROR_JORNADA_COMPLETA:")) {
            String nombre = resultado.substring("ERROR_JORNADA_COMPLETA:".length());
            ra.addFlashAttribute("error", nombre + " ya completó su jornada de hoy.");
        } else {
            ra.addFlashAttribute("error", "No se pudo registrar la asistencia.");
        }
        return "redirect:/asistencias/kiosk";
    }

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeEditarAsistencias()) return "redirect:/asistencias";
        model.addAttribute("asistencia", asistenciaService.findById(id)
                .orElseThrow(() -> new RuntimeException("Asistencia no encontrada: " + id)));
        model.addAttribute("asistencias", asistenciaService.findAll());
        model.addAttribute("personales", personalService.findAll());
        model.addAttribute("turnosPorTrabajador", mapaTurnos());
        model.addAttribute("asSvc", asistenciaService);
        model.addAttribute("editando", true);
        model.addAttribute("modoPersonal", false);
        model.addAttribute("soloLectura", false);
        model.addAttribute("soloPropio", false);
        model.addAttribute("usuario", u);
        return "asistencias/lista";
    }

    @PostMapping("/actualizar")
    public String actualizar(@ModelAttribute Asistencia asistencia, HttpSession session, RedirectAttributes ra) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeEditarAsistencias()) return "redirect:/asistencias";
        asistenciaService.update(asistencia);
        ra.addFlashAttribute("mensaje", "Asistencia actualizada.");
        return "redirect:/asistencias";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeEditarAsistencias()) return "redirect:/asistencias";
        asistenciaService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Registro eliminado.");
        return "redirect:/asistencias";
    }
}
