package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Miembro;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.CobroService;
import com.gym.gymsystem.service.MembresiaService;
import com.gym.gymsystem.service.MiembroService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping("/miembros")
public class MiembroController {

    private final MiembroService miembroService;
    private final CobroService cobroService;
    private final MembresiaService membresiaService;

    public MiembroController(MiembroService miembroService, CobroService cobroService, MembresiaService membresiaService) {
        this.miembroService = miembroService;
        this.cobroService = cobroService;
        this.membresiaService = membresiaService;
    }

    private Usuario usuarioORedirect(HttpSession session) {
        return (Usuario) session.getAttribute("usuarioLogueado");
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q, Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("miembros", miembroService.buscar(q));
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("usuario", u);
        model.addAttribute("q", q != null ? q : "");
        model.addAttribute("creando", false);
        model.addAttribute("editando", false);
        return "miembros/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoForm(Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("miembros", miembroService.findAll());
        model.addAttribute("miembro", new Miembro());
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("creando", true);
        model.addAttribute("editando", false);
        model.addAttribute("usuario", u);
        model.addAttribute("q", "");
        return "miembros/lista";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Miembro miembro, RedirectAttributes ra) {
        if (miembro.getDni() == null || miembro.getDni().isBlank()) {
            ra.addFlashAttribute("error", "El DNI del cliente es obligatorio.");
            return "redirect:/miembros/nuevo";
        }
        String dniNorm = miembro.getDni().trim();
        if (miembroService.findByDni(dniNorm).isPresent()) {
            ra.addFlashAttribute("error", "Ya existe un cliente con el DNI " + dniNorm + ".");
            return "redirect:/miembros/nuevo";
        }
        miembro.setDni(dniNorm);
        miembroService.save(miembro);
        ra.addFlashAttribute("mensaje", "Miembro registrado. Membresía activa por " +
                Miembro.diasDePlan(miembro.getMembresia()) + " días.");
        return "redirect:/miembros";
    }

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("miembro", miembroService.findById(id)
                .orElseThrow(() -> new RuntimeException("Miembro no encontrado: " + id)));
        model.addAttribute("miembros", miembroService.findAll());
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("editando", true);
        model.addAttribute("creando", false);
        model.addAttribute("usuario", u);
        model.addAttribute("q", "");
        return "miembros/lista";
    }

    @PostMapping("/actualizar")
    public String actualizar(@ModelAttribute Miembro miembro, RedirectAttributes ra) {
        if (miembro.getDni() == null || miembro.getDni().isBlank()) {
            ra.addFlashAttribute("error", "El DNI del cliente es obligatorio.");
            return "redirect:/miembros";
        }
        String dniNorm = miembro.getDni().trim();
        Optional<Miembro> duplicado = miembroService.findByDni(dniNorm);
        if (duplicado.isPresent() && !duplicado.get().getId().equals(miembro.getId())) {
            ra.addFlashAttribute("error", "Ya existe un cliente con el DNI " + dniNorm + ".");
            return "redirect:/miembros";
        }
        miembro.setDni(dniNorm);
        miembroService.update(miembro);
        ra.addFlashAttribute("mensaje", "Miembro actualizado correctamente.");
        return "redirect:/miembros";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        miembroService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Miembro eliminado.");
        return "redirect:/miembros";
    }

    @GetMapping("/ficha/{id}")
    public String ficha(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        Miembro miembro = miembroService.findById(id)
                .orElseThrow(() -> new RuntimeException("Miembro no encontrado: " + id));
        model.addAttribute("miembro", miembro);
        model.addAttribute("historialCobros", cobroService.findByMiembroId(miembro.getId()));
        model.addAttribute("usuario", u);
        return "miembros/ficha";
    }
}
