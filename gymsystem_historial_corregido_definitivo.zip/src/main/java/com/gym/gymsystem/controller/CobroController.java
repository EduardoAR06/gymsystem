package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Cobro;
import com.gym.gymsystem.model.Miembro;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.CobroService;
import com.gym.gymsystem.service.MembresiaService;
import com.gym.gymsystem.service.MiembroService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/cobros")
public class CobroController {

    private final CobroService cobroService;
    private final MiembroService miembroService;
    private final MembresiaService membresiaService;

    public CobroController(CobroService cobroService, MiembroService miembroService, MembresiaService membresiaService) {
        this.cobroService = cobroService;
        this.miembroService = miembroService;
        this.membresiaService = membresiaService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q, Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("cobros", cobroService.buscar(q));
        model.addAttribute("usuario", u);
        model.addAttribute("q", q != null ? q : "");
        model.addAttribute("creando", false);
        model.addAttribute("editando", false);
        return "cobros/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoForm(Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("cobros", cobroService.findAll());
        model.addAttribute("cobro", new Cobro());
        model.addAttribute("miembros", miembroService.findAll());
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("precios", buildPreciosMap());
        model.addAttribute("creando", true);
        model.addAttribute("editando", false);
        model.addAttribute("usuario", u);
        model.addAttribute("q", "");
        return "cobros/lista";
    }

    @GetMapping("/buscar")
    @ResponseBody
    public List<Miembro> buscarMiembros(@RequestParam String q) {
        return miembroService.buscar(q).stream().limit(10).toList();
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Cobro cobro,
                          @RequestParam(required = false) Long miembroIdForm,
                          @RequestParam(required = false) String miembroNombreForm,
                          RedirectAttributes ra) {
        Long mid = cobro.getMiembroId() != null ? cobro.getMiembroId() : miembroIdForm;
        if (mid != null) {
            miembroService.findById(mid).ifPresent(m -> {
                cobro.setMiembroId(m.getId());
                cobro.setMiembroNombre(m.getNombres());
            });
        } else if (miembroNombreForm != null) {
            cobro.setMiembroNombre(miembroNombreForm);
        }
        cobroService.save(cobro);
        if (mid != null && cobro.getPlanPagado() != null) {
            int cobrosDelMiembro = cobroService.findByMiembroId(mid).size();
            miembroService.findById(mid).ifPresent(antes -> {
                boolean esPrimerCobro = cobrosDelMiembro == 1;
                boolean membresiaActiva = antes.getDiasRestantes() > 0;

                if (esPrimerCobro && membresiaActiva) {
                    ra.addFlashAttribute("mensaje",
                            "Cobro registrado. La membresía ya estaba activa desde el alta del cliente.");
                    return;
                }

                int diasAntes = antes.getDiasRestantes();
                int diasPlan = Miembro.diasDePlan(cobro.getPlanPagado());
                miembroService.renovarMembresia(mid, cobro.getPlanPagado());
                miembroService.findById(mid).ifPresent(despues -> {
                    if (diasAntes > 0) {
                        ra.addFlashAttribute("mensaje",
                                "Cobro registrado. Se acumularon " + diasAntes + " días restantes + "
                                        + diasPlan + " del plan = " + despues.getDiasRestantes() + " días totales.");
                    } else {
                        ra.addFlashAttribute("mensaje",
                                "Cobro registrado. Membresía activa por " + despues.getDiasRestantes() + " días.");
                    }
                });
            });
            if (!ra.getFlashAttributes().containsKey("mensaje")) {
                ra.addFlashAttribute("mensaje", "Cobro registrado. Membresía renovada automáticamente.");
            }
        } else {
            ra.addFlashAttribute("mensaje", "Cobro registrado.");
        }
        return "redirect:/cobros";
    }

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        model.addAttribute("cobro", cobroService.findById(id)
                .orElseThrow(() -> new RuntimeException("Cobro no encontrado: " + id)));
        model.addAttribute("cobros", cobroService.findAll());
        model.addAttribute("miembros", miembroService.findAll());
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("precios", buildPreciosMap());
        model.addAttribute("editando", true);
        model.addAttribute("creando", false);
        model.addAttribute("usuario", u);
        model.addAttribute("q", "");
        return "cobros/lista";
    }

    @PostMapping("/actualizar")
    public String actualizar(@ModelAttribute Cobro cobro, RedirectAttributes ra) {
        cobroService.update(cobro);
        ra.addFlashAttribute("mensaje", "Cobro actualizado.");
        return "redirect:/cobros";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        cobroService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Cobro eliminado.");
        return "redirect:/cobros";
    }

    /**
     * Mapa nombreCompleto → precio para el JS de autocompletado de monto.
     * Clave: "Mensual Estándar", "Trimestral VIP", etc.
     */
    private Map<String, Double> buildPreciosMap() {
        Map<String, Double> map = new LinkedHashMap<>();
        membresiaService.findAll().forEach(m -> map.put(m.getNombreCompleto(), m.getPrecio()));
        return map;
    }
}
