package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Membresia;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.CategoriaService;
import com.gym.gymsystem.service.MembresiaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/membresias")
public class MembresiaController {

    private final MembresiaService membresiaService;
    private final CategoriaService categoriaService;

    public MembresiaController(MembresiaService membresiaService, CategoriaService categoriaService) {
        this.membresiaService = membresiaService;
        this.categoriaService = categoriaService;
    }

    private Usuario usuarioORedirect(HttpSession session) {
        return (Usuario) session.getAttribute("usuarioLogueado");
    }

    private void modeloBase(Model model, Usuario u) {
        model.addAttribute("membresias", membresiaService.findAll());
        model.addAttribute("categorias", categoriaService.findAll());
        model.addAttribute("usuario", u);
        model.addAttribute("membresia", new Membresia());
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        modeloBase(model, u);
        return "membresias/lista";
    }

    @GetMapping("/nueva")
    public String nuevaForm(Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        modeloBase(model, u);
        model.addAttribute("creando", true);
        return "membresias/lista";
    }

    @PostMapping("/guardar")
    public String guardar(@RequestParam String plan,
                          @RequestParam Double precio,
                          @RequestParam String duracion,
                          @RequestParam Long categoriaId,
                          RedirectAttributes ra) {
        Membresia m = new Membresia();
        m.setPlan(plan);
        m.setPrecio(precio);
        m.setDuracion(duracion);
        m.setCategoriaId(categoriaId);
        categoriaService.findById(categoriaId).ifPresent(c -> m.setCategoriaNombre(c.getNombre()));
        membresiaService.save(m);
        ra.addFlashAttribute("mensaje", "Membresía creada correctamente.");
        return "redirect:/membresias";
    }

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        Membresia m = membresiaService.findById(id)
                .orElseThrow(() -> new RuntimeException("Membresía no encontrada: " + id));
        modeloBase(model, u);
        model.addAttribute("membresia", m);
        model.addAttribute("editando", true);
        return "membresias/lista";
    }

    @PostMapping("/actualizar")
    public String actualizar(@RequestParam Long id,
                             @RequestParam String plan,
                             @RequestParam Double precio,
                             @RequestParam String duracion,
                             @RequestParam Long categoriaId,
                             RedirectAttributes ra) {
        Membresia m = membresiaService.findById(id)
                .orElseThrow(() -> new RuntimeException("Membresía no encontrada: " + id));
        m.setPlan(plan);
        m.setPrecio(precio);
        m.setDuracion(duracion);
        m.setCategoriaId(categoriaId);
        categoriaService.findById(categoriaId).ifPresent(c -> m.setCategoriaNombre(c.getNombre()));
        membresiaService.update(m);
        ra.addFlashAttribute("mensaje", "Membresía actualizada correctamente.");
        return "redirect:/membresias";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        Usuario u = usuarioORedirect(session);
        if (u == null) return "redirect:/";
        if (!u.puedeMembresias()) return "redirect:/main";
        membresiaService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Membresía eliminada.");
        return "redirect:/membresias";
    }
}
