package com.gym.gymsystem.controller;

import com.gym.gymsystem.model.Personal;
import com.gym.gymsystem.model.Usuario;
import com.gym.gymsystem.service.PersonalService;
import com.gym.gymsystem.service.RolService;
import com.gym.gymsystem.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/personal")
public class PersonalController {

    private final PersonalService personalService;
    private final UsuarioService  usuarioService;
    private final RolService      rolService;

    public PersonalController(PersonalService personalService, UsuarioService usuarioService,
                              RolService rolService) {
        this.personalService = personalService;
        this.usuarioService  = usuarioService;
        this.rolService      = rolService;
    }

    private Map<String, Usuario> mapaUsuariosPorNombre() {
        Map<String, Usuario> map = new HashMap<>();
        usuarioService.findAll().forEach(u -> map.put(u.getNombres(), u));
        return map;
    }

    private void atributosLista(Model model, Usuario u, String q) {
        model.addAttribute("personales", personalService.buscar(q));
        model.addAttribute("personal",   new Personal());
        model.addAttribute("usuario",    u);
        model.addAttribute("q", q != null ? q : "");
        model.addAttribute("usuarioPorNombre", mapaUsuariosPorNombre());
        model.addAttribute("rolesAsignables", rolService.findAsignablesAPersonal());
        model.addAttribute("rolNombres", rolService.findAll().stream()
                .collect(java.util.stream.Collectors.toMap(
                        com.gym.gymsystem.model.RolSistema::getCodigo,
                        com.gym.gymsystem.model.RolSistema::getNombre,
                        (a, b) -> a)));
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q, Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeVerPersonal()) return "redirect:/main";
        atributosLista(model, u, q);
        return "personal/lista";
    }

    @PostMapping("/guardar")
    public String guardar(
            @ModelAttribute Personal personal,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String password,
            @RequestParam(required = false) String rolCodigo,
            HttpSession session,
            RedirectAttributes ra) {

        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null || !u.puedeEditarPersonal()) return "redirect:/personal";

        if (personal.getDni() == null || personal.getDni().isBlank()) {
            ra.addFlashAttribute("error", "El DNI es obligatorio.");
            return "redirect:/personal";
        }
        if ((username == null || username.isBlank())
                && (password == null || password.isBlank())
                && (rolCodigo == null || rolCodigo.isBlank())) {
            personalService.save(personal);
            ra.addFlashAttribute("mensaje", "Personal registrado.");
            return "redirect:/personal";
        }

        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            ra.addFlashAttribute("error", "Usuario y contraseña son obligatorios.");
            return "redirect:/personal";
        }
        if (rolCodigo == null || rolCodigo.isBlank()) {
            ra.addFlashAttribute("error", "Debe asignar un rol al personal.");
            return "redirect:/personal";
        }
        if (rolService.findByCodigo(rolCodigo).isEmpty()) {
            ra.addFlashAttribute("error", "El rol seleccionado no es válido.");
            return "redirect:/personal";
        }
        if ("ADMIN".equals(rolCodigo) || "KIOSK_ASIS".equals(rolCodigo)) {
            ra.addFlashAttribute("error", "No puede asignar el rol Administrador o Terminal desde aquí.");
            return "redirect:/personal";
        }

        String dniNorm = personal.getDni().trim();
        if (personalService.findByDni(dniNorm).isPresent()) {
            ra.addFlashAttribute("error", "Ya existe personal con el DNI " + dniNorm + ".");
            return "redirect:/personal";
        }
        personal.setDni(dniNorm);

        if (usuarioService.existeUsername(username.trim())) {
            ra.addFlashAttribute("error", "El usuario '" + username.trim() + "' ya está en uso.");
            return "redirect:/personal";
        }

        personalService.save(personal);

        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setNombres(personal.getNombres());
        nuevoUsuario.setUsername(username.trim());
        nuevoUsuario.setPassword(password.trim());
        nuevoUsuario.setRol(rolCodigo.trim());
        usuarioService.save(nuevoUsuario);

        ra.addFlashAttribute("mensaje",
                "Personal registrado con acceso: " + username.trim()
                        + " — Rol: " + rolService.nombreDeRol(rolCodigo));
        return "redirect:/personal";
    }

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model, HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null) return "redirect:/";
        if (!u.puedeEditarPersonal()) return "redirect:/personal";
        model.addAttribute("personal",  personalService.findById(id)
                .orElseThrow(() -> new RuntimeException("Personal no encontrado: " + id)));
        model.addAttribute("personales", personalService.findAll());
        model.addAttribute("editando",   true);
        model.addAttribute("usuario",    u);
        model.addAttribute("usuarioPorNombre", mapaUsuariosPorNombre());
        model.addAttribute("rolesAsignables", rolService.findAsignablesAPersonal());
        model.addAttribute("rolNombres", rolService.findAll().stream()
                .collect(java.util.stream.Collectors.toMap(
                        com.gym.gymsystem.model.RolSistema::getCodigo,
                        com.gym.gymsystem.model.RolSistema::getNombre,
                        (a, b) -> a)));
        return "personal/lista";
    }

    @PostMapping("/actualizar")
    public String actualizar(@ModelAttribute Personal personal, HttpSession session, RedirectAttributes ra) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null || !u.puedeEditarPersonal()) return "redirect:/personal";
        if (personal.getDni() == null || personal.getDni().isBlank()) {
            ra.addFlashAttribute("error", "El DNI es obligatorio.");
            return "redirect:/personal";
        }
        String dniNorm = personal.getDni().trim();
        Optional<Personal> duplicado = personalService.findByDni(dniNorm);
        if (duplicado.isPresent() && !duplicado.get().getId().equals(personal.getId())) {
            ra.addFlashAttribute("error", "Ya existe personal con el DNI " + dniNorm + ".");
            return "redirect:/personal";
        }
        personal.setDni(dniNorm);
        personalService.update(personal);
        ra.addFlashAttribute("mensaje", "Personal actualizado.");
        return "redirect:/personal";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u == null || !u.puedeEditarPersonal()) return "redirect:/personal";
        personalService.findById(id).ifPresent(p ->
                usuarioService.findAll().stream()
                        .filter(us -> p.getNombres().equals(us.getNombres()))
                        .findFirst()
                        .ifPresent(us -> usuarioService.deleteById(us.getId())));
        personalService.deleteById(id);
        ra.addFlashAttribute("mensaje", "Personal eliminado.");
        return "redirect:/personal";
    }
}
