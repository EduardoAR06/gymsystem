package com.gym.gymsystem.service;

import com.gym.gymsystem.adapter.MiembroAdapter;
import com.gym.gymsystem.entity.MiembroEntity;
import com.gym.gymsystem.model.Miembro;
import com.gym.gymsystem.repository.MiembroRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MiembroService {
    private final MiembroRepository repo;
    private final MiembroAdapter adapter;
    public MiembroService(MiembroRepository repo, MiembroAdapter adapter) { this.repo = repo; this.adapter = adapter; }

    public List<Miembro> findAll() {
        return repo.findAll().stream().map(e -> { Miembro m = adapter.toModel(e); m.actualizarEstado(); return m; }).collect(Collectors.toList());
    }
    public Optional<Miembro> findById(Long id) {
        return repo.findById(id).map(e -> { Miembro m = adapter.toModel(e); m.actualizarEstado(); return m; });
    }
    public Optional<Miembro> findByDni(String dni) {
        return repo.findByDni(dni).map(e -> { Miembro m = adapter.toModel(e); m.actualizarEstado(); return m; });
    }
    public List<Miembro> buscar(String q) {
        if (q == null || q.isBlank()) return findAll();
        String term = q.trim().toLowerCase();
        return findAll().stream()
                .filter(m -> (m.getNombres() != null && m.getNombres().toLowerCase().contains(term))
                        || (m.getDni() != null && m.getDni().toLowerCase().contains(term))
                        || (m.getMembresia() != null && m.getMembresia().toLowerCase().contains(term))
                        || (m.getEstado() != null && m.getEstado().toLowerCase().contains(term)))
                .collect(Collectors.toList());
    }
    public void save(Miembro m) {
        int dias = Miembro.diasDePlan(m.getMembresia());
        m.setFechaVencimiento(LocalDate.now().plusDays(dias));
        m.actualizarEstado();
        repo.save(adapter.toEntity(m));
    }
    public void update(Miembro m) { m.actualizarEstado(); repo.save(adapter.toEntity(m)); }
    public void renovarMembresia(Long id, String planPagado) {
        repo.findById(id).ifPresent(e -> {
            Miembro m = adapter.toModel(e); m.actualizarEstado();
            int diasNuevos = Miembro.diasDePlan(planPagado);
            LocalDate base = (m.getDiasRestantes() > 0 && m.getFechaVencimiento() != null)
                    ? m.getFechaVencimiento() : LocalDate.now();
            m.setMembresia(planPagado);
            m.setFechaVencimiento(base.plusDays(diasNuevos));
            m.actualizarEstado();
            repo.save(adapter.toEntity(m));
        });
    }
    public void deleteById(Long id) { repo.deleteById(id); }
    public long countTotal() { return repo.count(); }
    public long countActivos() { return repo.countActivos(); }
}
