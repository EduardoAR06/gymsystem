package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.MiembroEntity;
import com.gym.gymsystem.model.Miembro;
import org.springframework.stereotype.Component;

@Component
public class MiembroAdapter {
    public Miembro toModel(MiembroEntity e) {
        if (e == null) return null;
        Miembro m = new Miembro();
        m.setId(e.getId());
        m.setNombres(e.getNombres());
        m.setDni(e.getDni());
        m.setTelefono(e.getTelefono());
        m.setMembresia(e.getMembresia());
        m.setEstado(e.getEstado());
        m.setDiasRestantes(e.getDiasRestantes());
        m.setFechaVencimiento(e.getFechaVencimiento());
        return m;
    }
    public MiembroEntity toEntity(Miembro m) {
        if (m == null) return null;
        MiembroEntity e = new MiembroEntity();
        e.setId(m.getId());
        e.setNombres(m.getNombres());
        e.setDni(m.getDni());
        e.setTelefono(m.getTelefono());
        e.setMembresia(m.getMembresia());
        e.setEstado(m.getEstado());
        e.setDiasRestantes(m.getDiasRestantes());
        e.setFechaVencimiento(m.getFechaVencimiento());
        return e;
    }
}
