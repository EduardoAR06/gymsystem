package com.gym.gymsystem.adapter;

import com.gym.gymsystem.entity.CobroEntity;
import com.gym.gymsystem.model.Cobro;
import org.springframework.stereotype.Component;

@Component
public class CobroAdapter {
    public Cobro toModel(CobroEntity e) {
        if (e == null) return null;
        Cobro m = new Cobro();
        m.setId(e.getId());
        m.setMiembroId(e.getMiembroId());
        m.setMiembroNombre(e.getMiembroNombre());
        m.setPlanPagado(e.getPlanPagado());
        m.setMonto(e.getMonto());
        m.setMetodoPago(e.getMetodoPago());
        m.setEstado(e.getEstado());
        m.setFecha(e.getFecha());
        return m;
    }
    public CobroEntity toEntity(Cobro m) {
        if (m == null) return null;
        CobroEntity e = new CobroEntity();
        e.setId(m.getId());
        e.setMiembroId(m.getMiembroId());
        e.setMiembroNombre(m.getMiembroNombre());
        e.setPlanPagado(m.getPlanPagado());
        e.setMonto(m.getMonto());
        e.setMetodoPago(m.getMetodoPago());
        e.setEstado(m.getEstado());
        e.setFecha(m.getFecha());
        return e;
    }
}
