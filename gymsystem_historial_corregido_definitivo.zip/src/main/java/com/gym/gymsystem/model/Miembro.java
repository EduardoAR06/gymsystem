package com.gym.gymsystem.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Miembro {
    private Long id;
    private String nombres;
    private String dni;
    private String telefono;
    private String membresia;
    private String estado;
    private int diasRestantes;
    private LocalDate fechaVencimiento;
    public Miembro() {}

    public void actualizarEstado() {
        if (fechaVencimiento != null) {
            long dias = ChronoUnit.DAYS.between(LocalDate.now(), fechaVencimiento);
            diasRestantes = (int) Math.max(0, dias);
        }
        this.estado = (diasRestantes > 0) ? "Activo" : "Inactivo";
    }

    public static int diasDePlan(String tipoPlan) {
        if (tipoPlan == null) return 30;
        String lower = tipoPlan.toLowerCase();
        if (lower.contains("trimestral")) return 90;
        if (lower.contains("anual")) return 360;
        return 30;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombres() { return nombres; }
    public void setNombres(String v) { this.nombres = v; }
    public String getDni() { return dni; }
    public void setDni(String v) { this.dni = v; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String v) { this.telefono = v; }
    public String getMembresia() { return membresia; }
    public void setMembresia(String v) { this.membresia = v; }
    public String getEstado() { return estado; }
    public void setEstado(String v) { this.estado = v; }
    public int getDiasRestantes() { return diasRestantes; }
    public void setDiasRestantes(int v) { this.diasRestantes = v; }
    public LocalDate getFechaVencimiento() { return fechaVencimiento; }
    public void setFechaVencimiento(LocalDate v) { this.fechaVencimiento = v; }
}
