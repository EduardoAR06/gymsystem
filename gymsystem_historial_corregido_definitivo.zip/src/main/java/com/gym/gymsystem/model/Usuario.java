package com.gym.gymsystem.model;

import java.util.ArrayList;
import java.util.List;

public class Usuario {
    private Long id;
    private String username;
    private String password;
    private String rol;
    private String nombres;
    private List<String> permisos = new ArrayList<>();
    private String rolNombreDisplay;
    public Usuario() {}
    public Usuario(String username, String password, String rol, String nombres) {
        this.username = username; this.password = password; this.rol = rol; this.nombres = nombres;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String v) { this.username = v; }
    public String getPassword() { return password; }
    public void setPassword(String v) { this.password = v; }
    public String getRol() { return rol; }
    public void setRol(String v) { this.rol = v; }
    public String getNombres() { return nombres; }
    public void setNombres(String v) { this.nombres = v; }
    public List<String> getPermisos() { return permisos; }
    public void setPermisos(List<String> p) { this.permisos = p != null ? new ArrayList<>(p) : new ArrayList<>(); }
    public boolean tienePermiso(String permiso) {
        if (permisos.contains(Permisos.ALL)) return true;
        return permisos.contains(permiso);
    }
    public boolean isAdmin()     { return "ADMIN".equals(rol); }
    public boolean isRecepMem()  { return "RECEP_MEM".equals(rol); }
    public boolean isRecepAsis() { return "RECEP_ASIS".equals(rol); }
    public boolean isPersonal()  { return "PERSONAL".equals(rol); }
    public boolean isKioskAsis() { return "KIOSK_ASIS".equals(rol); }
    public boolean isHistAsis() { return "HIST_ASIS".equals(rol); }
    public boolean puedeMembresias()                      { return tienePermiso(Permisos.MIEMBROS) || tienePermiso(Permisos.COBROS); }
    public boolean puedeEditarAsistencias()               { return tienePermiso(Permisos.ASISTENCIAS_EDIT); }
    public boolean puedeVerHistorialCompletoAsistencias() { return tienePermiso(Permisos.ASISTENCIAS) || isHistAsis(); }
    public boolean puedeVerAsistencias()                  { return tienePermiso(Permisos.ASISTENCIAS) || tienePermiso(Permisos.ASISTENCIAS_PROPIAS); }
    public boolean puedeUsarKioskAsistencias()            { return isKioskAsis(); }
    public boolean puedeVerPersonal()                     { return tienePermiso(Permisos.PERSONAL) || tienePermiso(Permisos.PERSONAL_EDIT); }
    public boolean puedeEditarPersonal()                  { return tienePermiso(Permisos.PERSONAL_EDIT); }
    public boolean puedeGestionarRoles()                  { return tienePermiso(Permisos.ROLES); }
    public boolean puedeGestion()                         { return tienePermiso(Permisos.GESTION); }
    public boolean puedeAsistencias()                     { return puedeEditarAsistencias(); }
    public String getRolNombre() {
        if (rolNombreDisplay != null && !rolNombreDisplay.isBlank()) return rolNombreDisplay;
        if (rol == null) return "";
        return switch (rol) {
            case "ADMIN"      -> "Administrador";
            case "RECEP_MEM"  -> "Recep. Membresías";
            case "RECEP_ASIS" -> "Recep. Asistencias";
            case "PERSONAL"   -> "Personal";
            case "KIOSK_ASIS" -> "Terminal Asistencias";
            default           -> rol.replace("CUSTOM_", "").replace("_", " ");
        };
    }
    public String getRolNombreDisplay() { return rolNombreDisplay; }
    public void setRolNombreDisplay(String v) { this.rolNombreDisplay = v; }
}
