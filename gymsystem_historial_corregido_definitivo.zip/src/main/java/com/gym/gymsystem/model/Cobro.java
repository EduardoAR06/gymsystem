package com.gym.gymsystem.model;

import java.time.LocalDate;

public class Cobro {
    private Long id;
    private Long miembroId;
    private String miembroNombre;
    private String planPagado;
    private Double monto;
    private String metodoPago;
    private String estado;
    private LocalDate fecha;
    public Cobro() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getMiembroId() { return miembroId; }
    public void setMiembroId(Long v) { this.miembroId = v; }
    public String getMiembroNombre() { return miembroNombre; }
    public void setMiembroNombre(String v) { this.miembroNombre = v; }
    public String getPlanPagado() { return planPagado; }
    public void setPlanPagado(String v) { this.planPagado = v; }
    public Double getMonto() { return monto; }
    public void setMonto(Double v) { this.monto = v; }
    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String v) { this.metodoPago = v; }
    public String getEstado() { return estado; }
    public void setEstado(String v) { this.estado = v; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate v) { this.fecha = v; }
}
