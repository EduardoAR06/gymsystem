package com.gym.gymsystem.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity(name = "miembro")
@Table(name = "miembros")
public class MiembroEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String nombres;
    @Column(unique = true)
    private String dni;
    private String telefono;
    private String membresia;
    private String estado;
    private int diasRestantes;
    private LocalDate fechaVencimiento;
    public MiembroEntity() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombres() { return nombres; }
    public void setNombres(String v) { this.nombres = v; }
    public String getDni() { return dni; }
    public void setDni(String v) { this.dni = v; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String v) { this.telefono = v; }
    public String getMembresia() { return membresia; }
    public void setMembresia(String v) { this.membresia = v; }
    public String getEstado() { return estado; }
    public void setEstado(String v) { this.estado = v; }
    public int getDiasRestantes() { return diasRestantes; }
    public void setDiasRestantes(int v) { this.diasRestantes = v; }
    public LocalDate getFechaVencimiento() { return fechaVencimiento; }
    public void setFechaVencimiento(LocalDate v) { this.fechaVencimiento = v; }
}
